export interface Project {
  id: string
  name: string
  description: string
  status: "active" | "completed" | "on-hold"
  progress: number
  createdAt: string
  updatedAt: string
  dueDate: string
  team: {
    name: string
    role: string
    avatar: string
    tasks: number
  }[]
  tasks: {
    id: string
    title: string
    status: string
  }[]
}
