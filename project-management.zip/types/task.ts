export interface Task {
  id: string
  title: string
  description: string
  type: "Bug" | "Feature" | "Epic" | "Task"
  priority: "High" | "Medium" | "Low"
  status: string
  projectId: string
  projectName: string
  assignee: {
    id: string
    name: string
    role: string
    avatar: string
  }
  createdAt: string
  updatedAt: string
  dueDate: string
}
