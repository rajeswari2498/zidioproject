"use client"

import { ProjectsOverview } from "@/components/dashboard/projects-overview"
import { TasksOverview } from "@/components/dashboard/tasks-overview"
import { ActivityFeed } from "@/components/dashboard/activity-feed"
import { TeamWorkload } from "@/components/dashboard/team-workload"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { WelcomeBanner } from "@/components/dashboard/welcome-banner"
import { KanbanBoard } from "@/components/dashboard/kanban-board"
import { motion } from "framer-motion"
import { useState } from "react"
import { CreateTaskDialog } from "@/components/tasks/create-task-dialog"
import { CreateProjectDialog } from "@/components/projects/create-project-dialog"
import { ScheduleMeetingDialog } from "@/components/meetings/schedule-meeting-dialog"
import { CreateSprintDialog } from "@/components/sprints/create-sprint-dialog"

export default function DashboardPage() {
  const [isCreateTaskDialogOpen, setIsCreateTaskDialogOpen] = useState(false)
  const [isCreateProjectDialogOpen, setIsCreateProjectDialogOpen] = useState(false)
  const [isScheduleMeetingDialogOpen, setIsScheduleMeetingDialogOpen] = useState(false)
  const [isCreateSprintDialogOpen, setIsCreateSprintDialogOpen] = useState(false)

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <WelcomeBanner />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="space-y-1">
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Frequently used actions</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Button
                onClick={() => setIsCreateTaskDialogOpen(true)}
                className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
              >
                <Plus className="mr-2 h-4 w-4" /> New Task
              </Button>
              <Button onClick={() => setIsCreateProjectDialogOpen(true)} variant="outline" className="border-zinc-700">
                <Plus className="mr-2 h-4 w-4" /> New Project
              </Button>
              <Button
                onClick={() => setIsScheduleMeetingDialogOpen(true)}
                variant="outline"
                className="border-zinc-700"
              >
                Schedule Meeting
              </Button>
              <Button onClick={() => setIsCreateSprintDialogOpen(true)} variant="outline" className="border-zinc-700">
                Create Sprint
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <KanbanBoard />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="space-y-1">
              <CardTitle>Projects</CardTitle>
              <CardDescription>Your active projects</CardDescription>
            </div>
            <Button
              size="sm"
              className="bg-amber-500 hover:bg-amber-600 text-black"
              onClick={() => setIsCreateProjectDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-1" /> New
            </Button>
          </CardHeader>
          <CardContent>
            <ProjectsOverview />
          </CardContent>
        </Card>

        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="space-y-1">
              <CardTitle>Tasks</CardTitle>
              <CardDescription>Your assigned tasks</CardDescription>
            </div>
            <Button
              size="sm"
              className="bg-amber-500 hover:bg-amber-600 text-black"
              onClick={() => setIsCreateTaskDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-1" /> New
            </Button>
          </CardHeader>
          <CardContent>
            <TasksOverview />
          </CardContent>
        </Card>

        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="space-y-1">
              <CardTitle>Activity</CardTitle>
              <CardDescription>Recent project activity</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <ActivityFeed />
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader>
            <CardTitle>Team Workload</CardTitle>
            <CardDescription>Current workload distribution across team members</CardDescription>
          </CardHeader>
          <CardContent>
            <TeamWorkload />
          </CardContent>
        </Card>
      </motion.div>

      <CreateTaskDialog open={isCreateTaskDialogOpen} onOpenChange={setIsCreateTaskDialogOpen} />
      <CreateProjectDialog open={isCreateProjectDialogOpen} onOpenChange={setIsCreateProjectDialogOpen} />
      <ScheduleMeetingDialog open={isScheduleMeetingDialogOpen} onOpenChange={setIsScheduleMeetingDialogOpen} />
      <CreateSprintDialog open={isCreateSprintDialogOpen} onOpenChange={setIsCreateSprintDialogOpen} />
    </div>
  )
}
