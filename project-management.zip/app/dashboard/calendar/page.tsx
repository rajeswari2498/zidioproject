"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Plus, ChevronLeft, ChevronRight } from "lucide-react"
import { useTasks } from "@/hooks/use-tasks"
import { format, isSameDay, addMonths, subMonths } from "date-fns"
import { motion } from "framer-motion"

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState<Date>(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const { tasks } = useTasks()

  const handlePreviousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1))
  }

  const handleNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1))
  }

  // Get tasks for the selected date
  const selectedDateTasks = tasks.filter((task) => {
    const taskDate = new Date(task.dueDate)
    return selectedDate && isSameDay(taskDate, selectedDate)
  })

  // Get all dates with tasks for highlighting in the calendar
  const datesWithTasks = tasks.map((task) => new Date(task.dueDate))

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h1 className="text-3xl font-bold">Calendar</h1>
          <Button className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black">
            <Plus className="mr-2 h-4 w-4" /> Add Event
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <Card className="border-zinc-800 bg-zinc-900/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>{format(currentDate, "MMMM yyyy")}</CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={handlePreviousMonth} className="border-zinc-700">
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleNextMonth} className="border-zinc-700">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                month={currentDate}
                className="rounded-md border-zinc-800"
                modifiers={{
                  hasTasks: datesWithTasks,
                }}
                modifiersStyles={{
                  hasTasks: {
                    fontWeight: "bold",
                    textDecoration: "underline",
                    textDecorationColor: "#f59e0b",
                    textDecorationThickness: "2px",
                  },
                }}
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="border-zinc-800 bg-zinc-900/50">
            <CardHeader>
              <CardTitle>{selectedDate ? format(selectedDate, "MMMM d, yyyy") : "Select a date"}</CardTitle>
              <CardDescription>{selectedDateTasks.length} tasks due</CardDescription>
            </CardHeader>
            <CardContent>
              {selectedDateTasks.length > 0 ? (
                <div className="space-y-3">
                  {selectedDateTasks.map((task) => (
                    <div key={task.id} className="p-3 bg-zinc-800 rounded-md">
                      <div className="flex justify-between items-start mb-2">
                        <Badge
                          variant="outline"
                          className={
                            task.type === "Bug"
                              ? "border-red-500 text-red-500"
                              : task.type === "Feature"
                                ? "border-blue-500 text-blue-500"
                                : task.type === "Epic"
                                  ? "border-purple-500 text-purple-500"
                                  : "border-zinc-500 text-zinc-500"
                          }
                        >
                          {task.type}
                        </Badge>
                        <Badge
                          variant={
                            task.priority === "High" ? "default" : task.priority === "Medium" ? "outline" : "secondary"
                          }
                          className={
                            task.priority === "High"
                              ? "bg-red-500 text-white"
                              : task.priority === "Medium"
                                ? "border-amber-500 text-amber-500"
                                : "bg-blue-500 text-white"
                          }
                        >
                          {task.priority}
                        </Badge>
                      </div>
                      <h4 className="font-medium mb-1">{task.title}</h4>
                      <div className="flex justify-between items-center text-xs text-zinc-400">
                        <span>{task.projectName}</span>
                        <Badge
                          variant="outline"
                          className={
                            task.status === "Done"
                              ? "border-green-500 text-green-500"
                              : task.status === "In Progress"
                                ? "border-blue-500 text-blue-500"
                                : task.status === "Review"
                                  ? "border-purple-500 text-purple-500"
                                  : "border-zinc-500 text-zinc-500"
                          }
                        >
                          {task.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-zinc-400">
                  {selectedDate ? "No tasks due on this date" : "Select a date to view tasks"}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
