"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Search, Filter } from "lucide-react"
import { TaskList } from "@/components/tasks/task-list"
import { CreateTaskDialog } from "@/components/tasks/create-task-dialog"
import { useTasks } from "@/hooks/use-tasks"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

export default function TasksPage() {
  const { tasks } = useTasks()
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState({
    priority: {
      high: true,
      medium: true,
      low: true,
    },
    status: {
      todo: true,
      inProgress: true,
      review: true,
      done: true,
    },
    type: {
      bug: true,
      feature: true,
      epic: true,
      task: true,
    },
  })

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesPriority = filters.priority[task.priority.toLowerCase() as keyof typeof filters.priority]
    const matchesStatus = filters.status[task.status.replace(/\s+/g, "").toLowerCase() as keyof typeof filters.status]
    const matchesType = filters.type[task.type.toLowerCase() as keyof typeof filters.type]

    return matchesSearch && matchesPriority && matchesStatus && matchesType
  })

  const activeFilterCount = Object.values(filters).reduce((count, filterGroup) => {
    return count + Object.values(filterGroup).filter((value) => !value).length
  }, 0)

  const toggleFilter = (category: keyof typeof filters, item: string) => {
    setFilters((prev) => ({
      ...prev,
      [category]: {
        ...prev[category],
        [item]: !prev[category][item as keyof (typeof prev)[category]],
      },
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold">Tasks</h1>
        <Button
          onClick={() => setIsCreateDialogOpen(true)}
          className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
        >
          <Plus className="mr-2 h-4 w-4" /> Create Task
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-500" />
          <Input
            placeholder="Search tasks..."
            className="pl-10 bg-zinc-800 border-zinc-700"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-zinc-700">
              <Filter className="mr-2 h-4 w-4" />
              Filters
              {activeFilterCount > 0 && (
                <Badge className="ml-2 bg-amber-500 text-black" variant="secondary">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56">
            <DropdownMenuLabel>Priority</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuCheckboxItem
              checked={filters.priority.high}
              onCheckedChange={() => toggleFilter("priority", "high")}
            >
              High
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.priority.medium}
              onCheckedChange={() => toggleFilter("priority", "medium")}
            >
              Medium
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.priority.low}
              onCheckedChange={() => toggleFilter("priority", "low")}
            >
              Low
            </DropdownMenuCheckboxItem>

            <DropdownMenuSeparator />
            <DropdownMenuLabel>Status</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuCheckboxItem
              checked={filters.status.todo}
              onCheckedChange={() => toggleFilter("status", "todo")}
            >
              To Do
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.status.inProgress}
              onCheckedChange={() => toggleFilter("status", "inProgress")}
            >
              In Progress
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.status.review}
              onCheckedChange={() => toggleFilter("status", "review")}
            >
              Review
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.status.done}
              onCheckedChange={() => toggleFilter("status", "done")}
            >
              Done
            </DropdownMenuCheckboxItem>

            <DropdownMenuSeparator />
            <DropdownMenuLabel>Type</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuCheckboxItem checked={filters.type.bug} onCheckedChange={() => toggleFilter("type", "bug")}>
              Bug
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.type.feature}
              onCheckedChange={() => toggleFilter("type", "feature")}
            >
              Feature
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filters.type.epic} onCheckedChange={() => toggleFilter("type", "epic")}>
              Epic
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filters.type.task} onCheckedChange={() => toggleFilter("type", "task")}>
              Task
            </DropdownMenuCheckboxItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <TaskList tasks={filteredTasks} />

      <CreateTaskDialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen} />
    </div>
  )
}
