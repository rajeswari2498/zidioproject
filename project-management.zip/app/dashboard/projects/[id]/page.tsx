"use client"

import { useParams } from "next/navigation"
import { useProjects } from "@/hooks/use-projects"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectOverview } from "@/components/projects/project-overview"
import { ProjectKanban } from "@/components/projects/project-kanban"
import { ProjectChat } from "@/components/projects/project-chat"
import { ProjectSettings } from "@/components/projects/project-settings"
import { ProjectAnalytics } from "@/components/projects/project-analytics"
import { ProjectSprint } from "@/components/projects/project-sprint"
import { NotFound } from "@/components/not-found"

export default function ProjectPage() {
  const { id } = useParams()
  const { getProjectById } = useProjects()
  const project = getProjectById(id as string)

  if (!project) {
    return <NotFound type="project" />
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{project.name}</h1>
        <p className="text-zinc-400 mt-1">{project.description}</p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="bg-zinc-800 border-zinc-700 p-1">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="kanban">Kanban Board</TabsTrigger>
          <TabsTrigger value="sprint">Sprint</TabsTrigger>
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="mt-6">
          <ProjectOverview project={project} />
        </TabsContent>
        <TabsContent value="kanban" className="mt-6">
          <ProjectKanban project={project} />
        </TabsContent>
        <TabsContent value="sprint" className="mt-6">
          <ProjectSprint project={project} />
        </TabsContent>
        <TabsContent value="chat" className="mt-6">
          <ProjectChat project={project} />
        </TabsContent>
        <TabsContent value="analytics" className="mt-6">
          <ProjectAnalytics project={project} />
        </TabsContent>
        <TabsContent value="settings" className="mt-6">
          <ProjectSettings project={project} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
