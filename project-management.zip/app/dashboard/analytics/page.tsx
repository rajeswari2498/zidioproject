"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectCompletionChart } from "@/components/analytics/project-completion-chart"
import { TaskDistributionChart } from "@/components/analytics/task-distribution-chart"
import { TeamPerformanceChart } from "@/components/analytics/team-performance-chart"
import { TimelineChart } from "@/components/analytics/timeline-chart"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("30")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold">Analytics</h1>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px] bg-zinc-800 border-zinc-700">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
            <SelectItem value="365">Last year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="bg-zinc-800 border-zinc-700 p-1">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="team">Team</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-zinc-800 bg-zinc-900/50">
              <CardHeader>
                <CardTitle>Project Completion</CardTitle>
                <CardDescription>Project completion rate over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ProjectCompletionChart timeRange={Number.parseInt(timeRange)} />
              </CardContent>
            </Card>

            <Card className="border-zinc-800 bg-zinc-900/50">
              <CardHeader>
                <CardTitle>Task Distribution</CardTitle>
                <CardDescription>Tasks by status and priority</CardDescription>
              </CardHeader>
              <CardContent>
                <TaskDistributionChart />
              </CardContent>
            </Card>
          </div>

          <Card className="border-zinc-800 bg-zinc-900/50">
            <CardHeader>
              <CardTitle>Team Performance</CardTitle>
              <CardDescription>Task completion by team member</CardDescription>
            </CardHeader>
            <CardContent>
              <TeamPerformanceChart timeRange={Number.parseInt(timeRange)} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="mt-6">
          <Card className="border-zinc-800 bg-zinc-900/50">
            <CardHeader>
              <CardTitle>Project Timeline</CardTitle>
              <CardDescription>Project progress and milestones</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <TimelineChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-zinc-800 bg-zinc-900/50">
              <CardHeader>
                <CardTitle>Tasks by Type</CardTitle>
                <CardDescription>Distribution of task types</CardDescription>
              </CardHeader>
              <CardContent>
                <TaskDistributionChart type="type" />
              </CardContent>
            </Card>

            <Card className="border-zinc-800 bg-zinc-900/50">
              <CardHeader>
                <CardTitle>Tasks by Priority</CardTitle>
                <CardDescription>Distribution of task priorities</CardDescription>
              </CardHeader>
              <CardContent>
                <TaskDistributionChart type="priority" />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="team" className="mt-6">
          <Card className="border-zinc-800 bg-zinc-900/50">
            <CardHeader>
              <CardTitle>Team Performance</CardTitle>
              <CardDescription>Detailed team performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <TeamPerformanceChart timeRange={Number.parseInt(timeRange)} detailed />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
