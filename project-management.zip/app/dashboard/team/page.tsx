"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Search, Mail, Trash2, UserPlus } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { toast } from "@/components/ui/use-toast"
import { motion } from "framer-motion"

export default function TeamPage() {
  const { user } = useAuth()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDepartment, setSelectedDepartment] = useState("all")
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false)
  const [newMember, setNewMember] = useState({
    name: "",
    email: "",
    role: "",
    department: "",
    phone: "",
  })

  // Mock team members data
  const [teamMembers, setTeamMembers] = useState([
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      role: "Frontend Developer",
      department: "Engineering",
      phone: "+1 (555) 123-4567",
      avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
      projects: ["Website Redesign", "Mobile App"],
      tasks: 8,
    },
    {
      id: "2",
      name: "Sarah Smith",
      email: "sarah@example.com",
      role: "UI/UX Designer",
      department: "Design",
      phone: "+1 (555) 234-5678",
      avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
      projects: ["Website Redesign", "Brand Refresh"],
      tasks: 5,
    },
    {
      id: "3",
      name: "Mike Johnson",
      email: "mike@example.com",
      role: "Backend Developer",
      department: "Engineering",
      phone: "+1 (555) 345-6789",
      avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
      projects: ["API Integration", "Database Migration"],
      tasks: 12,
    },
    {
      id: "4",
      name: "Emily Chen",
      email: "emily@example.com",
      role: "Project Manager",
      department: "Management",
      phone: "+1 (555) 456-7890",
      avatar: "https://ui-avatars.com/api/?name=Emily+Chen&background=random",
      projects: ["Website Redesign", "Mobile App", "API Integration"],
      tasks: 3,
    },
    {
      id: "5",
      name: "David Wilson",
      email: "david@example.com",
      role: "QA Engineer",
      department: "Engineering",
      phone: "+1 (555) 567-8901",
      avatar: "https://ui-avatars.com/api/?name=David+Wilson&background=random",
      projects: ["Website Redesign", "Mobile App"],
      tasks: 7,
    },
  ])

  const departments = ["Engineering", "Design", "Management", "Marketing", "Sales"]

  const filteredMembers = teamMembers.filter((member) => {
    const matchesSearch =
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.role.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesDepartment = selectedDepartment === "all" || member.department === selectedDepartment

    return matchesSearch && matchesDepartment
  })

  const handleAddMember = () => {
    if (!newMember.name || !newMember.email || !newMember.role || !newMember.department) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    const member = {
      id: `${teamMembers.length + 1}`,
      name: newMember.name,
      email: newMember.email,
      role: newMember.role,
      department: newMember.department,
      phone: newMember.phone || "Not provided",
      avatar: `https://ui-avatars.com/api/?name=${newMember.name.replace(" ", "+")}&background=random`,
      projects: [],
      tasks: 0,
    }

    setTeamMembers([...teamMembers, member])
    setNewMember({
      name: "",
      email: "",
      role: "",
      department: "",
      phone: "",
    })
    setIsAddMemberOpen(false)

    toast({
      title: "Team member added",
      description: `${member.name} has been added to the team`,
    })
  }

  const handleDeleteMember = (id: string) => {
    setTeamMembers(teamMembers.filter((member) => member.id !== id))
    toast({
      title: "Team member removed",
      description: "The team member has been removed",
    })
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="space-y-1">
              <CardTitle>Team Management</CardTitle>
              <CardDescription>Manage your team members and their roles</CardDescription>
            </div>
            {(user?.role === "admin" || user?.role === "project_manager") && (
              <Dialog open={isAddMemberOpen} onOpenChange={setIsAddMemberOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black">
                    <UserPlus className="mr-2 h-4 w-4" /> Add Member
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-zinc-900 border-zinc-800">
                  <DialogHeader>
                    <DialogTitle>Add Team Member</DialogTitle>
                    <DialogDescription>Add a new member to your team</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          placeholder="John Doe"
                          className="bg-zinc-800 border-zinc-700"
                          value={newMember.name}
                          onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="john@example.com"
                          className="bg-zinc-800 border-zinc-700"
                          value={newMember.email}
                          onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="role">Role</Label>
                        <Input
                          id="role"
                          placeholder="Frontend Developer"
                          className="bg-zinc-800 border-zinc-700"
                          value={newMember.role}
                          onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="department">Department</Label>
                        <Select
                          value={newMember.department}
                          onValueChange={(value) => setNewMember({ ...newMember, department: value })}
                        >
                          <SelectTrigger className="bg-zinc-800 border-zinc-700">
                            <SelectValue placeholder="Select department" />
                          </SelectTrigger>
                          <SelectContent>
                            {departments.map((dept) => (
                              <SelectItem key={dept} value={dept}>
                                {dept}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone (Optional)</Label>
                      <Input
                        id="phone"
                        placeholder="+1 (555) 123-4567"
                        className="bg-zinc-800 border-zinc-700"
                        value={newMember.phone}
                        onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      onClick={handleAddMember}
                      className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
                    >
                      <Plus className="mr-2 h-4 w-4" /> Add Member
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-400" />
                  <Input
                    placeholder="Search by name, email, or role..."
                    className="pl-10 bg-zinc-800 border-zinc-700"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <div className="w-full md:w-64">
                <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                  <SelectTrigger className="bg-zinc-800 border-zinc-700">
                    <SelectValue placeholder="Filter by department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    {departments.map((dept) => (
                      <SelectItem key={dept} value={dept}>
                        {dept}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="rounded-md border border-zinc-800 overflow-hidden">
              <div className="grid grid-cols-12 bg-zinc-800 p-4 text-xs font-medium text-zinc-400 uppercase">
                <div className="col-span-4">Member</div>
                <div className="col-span-2">Department</div>
                <div className="col-span-2">Projects</div>
                <div className="col-span-2">Tasks</div>
                <div className="col-span-2">Actions</div>
              </div>
              <div className="divide-y divide-zinc-800">
                {filteredMembers.length > 0 ? (
                  filteredMembers.map((member) => (
                    <div key={member.id} className="grid grid-cols-12 p-4 items-center hover:bg-zinc-800/50">
                      <div className="col-span-4 flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                          <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{member.name}</p>
                          <p className="text-sm text-zinc-400">{member.role}</p>
                        </div>
                      </div>
                      <div className="col-span-2">
                        <span className="inline-flex items-center rounded-full bg-zinc-800 px-2.5 py-0.5 text-xs font-medium">
                          {member.department}
                        </span>
                      </div>
                      <div className="col-span-2 text-sm">{member.projects.length}</div>
                      <div className="col-span-2 text-sm">{member.tasks}</div>
                      <div className="col-span-2 flex space-x-2">
                        <Button variant="outline" size="icon" className="h-8 w-8 border-zinc-700">
                          <Mail className="h-4 w-4" />
                        </Button>
                        {(user?.role === "admin" || user?.role === "project_manager") && (
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 border-zinc-700 hover:bg-red-900/20 hover:text-red-500 hover:border-red-800"
                            onClick={() => handleDeleteMember(member.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center text-zinc-400">
                    No team members found matching your search criteria
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
