"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, ArrowUp, Check, Clock, Globe, Layers, Shield, Users } from "lucide-react"
import Link from "next/link"
import { FeatureCard } from "@/components/landing/feature-card"
import { TestimonialCard } from "@/components/landing/testimonial-card"
import { DashboardPreview } from "@/components/landing/dashboard-preview"
import { ParticleBackground } from "@/components/landing/particle-background"
import { PricingCard } from "@/components/landing/pricing-card"
import { FaqItem } from "@/components/landing/faq-item"
import { useEffect, useRef, useState } from "react"
import { motion, useInView, useScroll, useTransform } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Home() {
  const [activeTab, setActiveTab] = useState("kanban")
  const heroRef = useRef(null)
  const featuresRef = useRef(null)
  const statsRef = useRef(null)
  const workflowRef = useRef(null)
  const testimonialsRef = useRef(null)
  const pricingRef = useRef(null)
  const faqRef = useRef(null)
  const topRef = useRef(null)

  const featuresInView = useInView(featuresRef, { once: true, amount: 0.2 })
  const statsInView = useInView(statsRef, { once: true, amount: 0.3 })
  const workflowInView = useInView(workflowRef, { once: true, amount: 0.2 })
  const testimonialsInView = useInView(testimonialsRef, { once: true, amount: 0.2 })
  const pricingInView = useInView(pricingRef, { once: true, amount: 0.2 })
  const faqInView = useInView(faqRef, { once: true, amount: 0.2 })

  const [showScrollTop, setShowScrollTop] = useState(false)

  // Demo videos for the "See it in action" section
  const demoVideos = [
    {
      title: "Task Management",
      description: "Create, assign, and track tasks with ease",
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-ycRzoJ8RKwo9NBBnpdCYNqus2dJsJf.png",
      type: "image",
    },
    {
      title: "Team Collaboration",
      description: "Work together seamlessly with real-time updates",
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wEYu7TOzpjFGIcHySqMBTuJPXFQAs8.png",
      type: "image",
    },
    {
      title: "Project Analytics",
      description: "Get insights into your team's performance",
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pIqHrANyPANubHecoioTX0PMY3Hs9Z.png",
      type: "image",
    },
  ]

  const [currentDemoIndex, setCurrentDemoIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDemoIndex((prev) => (prev + 1) % demoVideos.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [demoVideos.length])

  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  })

  const heroOpacity = useTransform(scrollYProgress, [0, 1], [1, 0])
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 0.9])

  // Check scroll position to show/hide scroll to top button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 500) {
        setShowScrollTop(true)
      } else {
        setShowScrollTop(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Scroll to top function
  const scrollToTop = () => {
    topRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  // Simulate active users
  const [activeUsers, setActiveUsers] = useState(1253)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveUsers((prev) => prev + Math.floor(Math.random() * 5) - 2)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // Simulate typing effect for the hero title
  const [displayText, setDisplayText] = useState("")
  const fullText = "Manage Projects Like a Pro."

  useEffect(() => {
    let i = 0
    const typingInterval = setInterval(() => {
      if (i < fullText.length) {
        setDisplayText(fullText.substring(0, i + 1))
        i++
      } else {
        clearInterval(typingInterval)
      }
    }, 100)

    return () => clearInterval(typingInterval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-zinc-900 text-white" ref={topRef}>
      <ParticleBackground />

      {/* Navigation */}
      <nav className="container mx-auto px-4 py-6 flex justify-between items-center relative z-10">
        <div className="flex items-center">
          <Link href="/" onClick={scrollToTop}>
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-300 to-yellow-600 cursor-pointer hover:scale-105 transition-transform">
              ProjectPro
            </span>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/login">
            <Button variant="ghost" className="text-white hover:text-amber-300">
              Login
            </Button>
          </Link>
          <Link href="/signup">
            <Button className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black">
              Get Started
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <motion.section
        ref={heroRef}
        style={{ opacity: heroOpacity, scale: heroScale }}
        className="container mx-auto px-4 py-20 flex flex-col items-center text-center relative z-10"
      >
        <Badge className="mb-4 py-1.5 px-4 bg-amber-500/20 text-amber-300 border-amber-500/30">
          <Users className="h-3.5 w-3.5 mr-1" /> {activeUsers.toLocaleString()} teams already using ProjectPro
        </Badge>
        <h1 className="text-4xl md:text-6xl font-bold mb-6 max-w-4xl leading-tight">
          {displayText}{" "}
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-300 to-yellow-600">
            Collaborate. Track. Deliver.
          </span>
        </h1>
        <p className="text-xl text-zinc-400 mb-10 max-w-2xl">
          A powerful, intuitive project management platform designed for teams of all sizes. Streamline your workflow
          and boost productivity with our modern, feature-rich solution.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/signup">
            <Button
              size="lg"
              className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
            >
              Get Started <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <Link href="/login">
            <Button size="lg" variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
              Login
            </Button>
          </Link>
        </div>

        <div className="mt-16 relative w-full max-w-5xl">
          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-amber-400 to-yellow-600 text-black px-4 py-2 rounded-full text-sm font-medium">
            See it in action
          </div>
          <div className="border border-zinc-800 rounded-xl overflow-hidden shadow-2xl shadow-amber-500/5 relative">
            {demoVideos.map((demo, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0 }}
                animate={{ opacity: index === currentDemoIndex ? 1 : 0 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0"
                style={{ display: index === currentDemoIndex ? "block" : "none" }}
              >
                {demo.type === "image" ? (
                  <img src={demo.src || "/placeholder.svg"} alt={demo.title} className="w-full h-auto object-cover" />
                ) : (
                  <video src={demo.src} autoPlay muted loop className="w-full h-auto object-cover" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 right-0 p-6 text-center">
                  <h3 className="text-xl font-bold text-white mb-2">{demo.title}</h3>
                  <p className="text-zinc-300">{demo.description}</p>
                </div>
              </motion.div>
            ))}

            {/* Navigation dots */}
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-10">
              {demoVideos.map((_, index) => (
                <button
                  key={index}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === currentDemoIndex ? "bg-amber-500 scale-125" : "bg-zinc-600"
                  }`}
                  onClick={() => setCurrentDemoIndex(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      {/* Stats Section */}
      <section ref={statsRef} className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={statsInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center"
        >
          <div className="p-6 bg-zinc-900/50 border border-zinc-800 rounded-xl">
            <div className="text-4xl font-bold text-amber-400 mb-2">98%</div>
            <div className="text-zinc-400">Customer Satisfaction</div>
          </div>
          <div className="p-6 bg-zinc-900/50 border border-zinc-800 rounded-xl">
            <div className="text-4xl font-bold text-amber-400 mb-2">10k+</div>
            <div className="text-zinc-400">Active Users</div>
          </div>
          <div className="p-6 bg-zinc-900/50 border border-zinc-800 rounded-xl">
            <div className="text-4xl font-bold text-amber-400 mb-2">30%</div>
            <div className="text-zinc-400">Productivity Boost</div>
          </div>
          <div className="p-6 bg-zinc-900/50 border border-zinc-800 rounded-xl">
            <div className="text-4xl font-bold text-amber-400 mb-2">24/7</div>
            <div className="text-zinc-400">Customer Support</div>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section ref={featuresRef} className="container mx-auto px-4 py-20 relative z-10">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={featuresInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Powerful Features for Modern Teams
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={featuresInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-zinc-400 max-w-2xl mx-auto"
          >
            Everything you need to manage projects efficiently and keep your team on the same page
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={featuresInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4, staggerChildren: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <FeatureCard
            icon={<Users className="h-10 w-10 text-amber-400" />}
            title="Role-Based Access"
            description="Customize permissions for team members based on their roles. Ensure the right people have access to the right information."
          />
          <FeatureCard
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-amber-400"
              >
                <rect width="6" height="6" x="4" y="4" rx="1" />
                <rect width="6" height="6" x="14" y="4" rx="1" />
                <rect width="6" height="6" x="4" y="14" rx="1" />
                <rect width="6" height="6" x="14" y="14" rx="1" />
              </svg>
            }
            title="Kanban Boards"
            description="Visualize your workflow with customizable Kanban boards. Drag and drop tasks between columns to track progress."
          />
          <FeatureCard
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-amber-400"
              >
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                <polyline points="14 2 14 8 20 8" />
                <path d="M8 13h2" />
                <path d="M8 17h2" />
                <path d="M14 13h2" />
                <path d="M14 17h2" />
              </svg>
            }
            title="Sprint Planning"
            description="Plan and manage sprints with ease. Allocate tasks, track progress, and visualize team velocity with burndown charts."
          />
          <FeatureCard
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-amber-400"
              >
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            }
            title="Real-time Chat"
            description="Communicate with your team in real-time. Share files, mention team members, and keep all project discussions in one place."
          />
          <FeatureCard
            icon={
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-amber-400"
              >
                <path d="M3 3v18h18" />
                <path d="m19 9-5 5-4-4-3 3" />
              </svg>
            }
            title="Analytics Dashboard"
            description="Gain insights into your team's performance with comprehensive analytics. Track task completion, team workload, and project progress."
          />
          <FeatureCard
            icon={<Clock className="h-10 w-10 text-amber-400" />}
            title="Time Tracking"
            description="Track time spent on tasks and projects. Generate reports to analyze team productivity and project costs."
          />
          <FeatureCard
            icon={<Shield className="h-10 w-10 text-amber-400" />}
            title="Advanced Security"
            description="Keep your project data secure with role-based permissions, encryption, and regular security updates."
          />
          <FeatureCard
            icon={<Layers className="h-10 w-10 text-amber-400" />}
            title="Custom Workflows"
            description="Create custom workflows that match your team's processes. Define stages, transitions, and automation rules."
          />
          <FeatureCard
            icon={<Globe className="h-10 w-10 text-amber-400" />}
            title="Global Accessibility"
            description="Access your projects from anywhere in the world. Our platform is optimized for all devices and connection speeds."
          />
        </motion.div>
      </section>

      {/* Workflow Section */}
      <section ref={workflowRef} className="container mx-auto px-4 py-20 relative z-10">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={workflowInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Streamline Your Workflow
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={workflowInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-zinc-400 max-w-2xl mx-auto"
          >
            See how ProjectPro transforms the way your team works
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={workflowInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="max-w-5xl mx-auto"
        >
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="bg-zinc-800 border-zinc-700 p-1 grid grid-cols-3 mb-8">
              <TabsTrigger value="kanban">Kanban Board</TabsTrigger>
              <TabsTrigger value="sprint">Sprint Planning</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="kanban" className="mt-6">
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 overflow-hidden">
                <h3 className="text-xl font-bold mb-4">Visualize Your Workflow</h3>
                <p className="text-zinc-400 mb-6">
                  Drag and drop tasks between columns to update their status in real-time.
                </p>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-zinc-800 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-medium">To Do</h4>
                      <Badge className="bg-zinc-700">4</Badge>
                    </div>
                    <div className="space-y-3">
                      <Card className="bg-zinc-900 border-zinc-700 p-3">
                        <div className="flex justify-between mb-2">
                          <Badge className="bg-blue-500 text-white">Feature</Badge>
                          <Badge variant="outline" className="border-amber-500 text-amber-500">
                            Medium
                          </Badge>
                        </div>
                        <h5 className="font-medium mb-2">Implement user authentication</h5>
                        <div className="flex justify-between items-center">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="https://ui-avatars.com/api/?name=John+Doe&background=random" />
                            <AvatarFallback>JD</AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-zinc-400">Due in 3 days</span>
                        </div>
                      </Card>
                      <Card className="bg-zinc-900 border-zinc-700 p-3">
                        <div className="flex justify-between mb-2">
                          <Badge className="bg-red-500 text-white">Bug</Badge>
                          <Badge variant="outline" className="border-red-500 text-red-500">
                            High
                          </Badge>
                        </div>
                        <h5 className="font-medium mb-2">Fix navigation bug on mobile</h5>
                        <div className="flex justify-between items-center">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="https://ui-avatars.com/api/?name=Sarah+Smith&background=random" />
                            <AvatarFallback>SS</AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-zinc-400">Due tomorrow</span>
                        </div>
                      </Card>
                    </div>
                  </div>

                  <div className="bg-zinc-800 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-medium">In Progress</h4>
                      <Badge className="bg-zinc-700">3</Badge>
                    </div>
                    <div className="space-y-3">
                      <Card className="bg-zinc-900 border-zinc-700 p-3">
                        <div className="flex justify-between mb-2">
                          <Badge className="bg-blue-500 text-white">Feature</Badge>
                          <Badge variant="outline" className="border-amber-500 text-amber-500">
                            Medium
                          </Badge>
                        </div>
                        <h5 className="font-medium mb-2">Implement responsive navigation</h5>
                        <div className="flex justify-between items-center">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="https://ui-avatars.com/api/?name=Mike+Johnson&background=random" />
                            <AvatarFallback>MJ</AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-zinc-400">Due in 3 days</span>
                        </div>
                      </Card>
                    </div>
                  </div>

                  <div className="bg-zinc-800 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-medium">Done</h4>
                      <Badge className="bg-zinc-700">2</Badge>
                    </div>
                    <div className="space-y-3">
                      <Card className="bg-zinc-900 border-zinc-700 p-3">
                        <div className="flex justify-between mb-2">
                          <Badge className="bg-blue-500 text-white">Feature</Badge>
                          <Badge variant="outline" className="border-green-500 text-green-500">
                            Done
                          </Badge>
                        </div>
                        <h5 className="font-medium mb-2">Design homepage mockup</h5>
                        <div className="flex justify-between items-center">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src="https://ui-avatars.com/api/?name=Sarah+Smith&background=random" />
                            <AvatarFallback>SS</AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-zinc-400">Completed</span>
                        </div>
                      </Card>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="sprint" className="mt-6">
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 overflow-hidden">
                <h3 className="text-xl font-bold mb-4">Plan and Track Sprints</h3>
                <p className="text-zinc-400 mb-6">
                  Organize tasks into sprints and track progress with burndown charts.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <Card className="bg-zinc-800 border-zinc-700 p-4">
                    <h4 className="font-medium mb-2">Sprint 1</h4>
                    <div className="text-sm text-zinc-400 mb-2">May 1 - May 14</div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Progress</span>
                      <span>100%</span>
                    </div>
                    <div className="w-full bg-zinc-700 h-2 rounded-full">
                      <div className="bg-green-500 h-2 rounded-full w-full"></div>
                    </div>
                    <div className="mt-4 text-sm text-zinc-400">Completed</div>
                  </Card>

                  <Card className="bg-zinc-800 border-amber-800/30 p-4 border-2">
                    <h4 className="font-medium mb-2">Sprint 2</h4>
                    <div className="text-sm text-zinc-400 mb-2">May 15 - May 28</div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Progress</span>
                      <span>35%</span>
                    </div>
                    <div className="w-full bg-zinc-700 h-2 rounded-full">
                      <div className="bg-amber-500 h-2 rounded-full w-[35%]"></div>
                    </div>
                    <div className="mt-4 text-sm text-amber-400">Active</div>
                  </Card>

                  <Card className="bg-zinc-800 border-zinc-700 p-4">
                    <h4 className="font-medium mb-2">Sprint 3</h4>
                    <div className="text-sm text-zinc-400 mb-2">May 29 - Jun 11</div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Progress</span>
                      <span>0%</span>
                    </div>
                    <div className="w-full bg-zinc-700 h-2 rounded-full">
                      <div className="bg-blue-500 h-2 rounded-full w-0"></div>
                    </div>
                    <div className="mt-4 text-sm text-zinc-400">Planned</div>
                  </Card>
                </div>

                <div className="bg-zinc-800 p-4 rounded-lg">
                  <h4 className="font-medium mb-4">Burndown Chart</h4>
                  <div className="h-[200px] bg-zinc-900 rounded-lg flex items-end p-4">
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1 relative">
                      <div className="absolute bottom-0 left-0 right-0 bg-amber-500 h-[10%]"></div>
                    </div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1 relative">
                      <div className="absolute bottom-0 left-0 right-0 bg-amber-500 h-[20%]"></div>
                    </div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1 relative">
                      <div className="absolute bottom-0 left-0 right-0 bg-amber-500 h-[30%]"></div>
                    </div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1 relative">
                      <div className="absolute bottom-0 left-0 right-0 bg-amber-500 h-[35%]"></div>
                    </div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1 relative">
                      <div className="absolute bottom-0 left-0 right-0 bg-amber-500 h-[35%]"></div>
                    </div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                    <div className="w-1/7 h-[90%] bg-amber-500/20 mx-1"></div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="mt-6">
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 overflow-hidden">
                <h3 className="text-xl font-bold mb-4">Comprehensive Analytics</h3>
                <p className="text-zinc-400 mb-6">Gain insights into your team's performance and project progress.</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-zinc-800 p-4 rounded-lg">
                    <h4 className="font-medium mb-4">Task Status Distribution</h4>
                    <div className="flex items-center justify-center h-[200px]">
                      <div className="w-[200px] h-[200px] rounded-full border-8 border-zinc-700 relative">
                        <div className="absolute inset-0 border-8 border-transparent border-t-amber-500 rounded-full transform rotate-[45deg]"></div>
                        <div className="absolute inset-0 border-8 border-transparent border-t-blue-500 border-r-blue-500 rounded-full transform rotate-[135deg]"></div>
                        <div className="absolute inset-0 border-8 border-transparent border-b-green-500 rounded-full transform rotate-[270deg]"></div>
                      </div>
                    </div>
                    <div className="flex justify-center gap-4 mt-4 text-sm">
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-amber-500 rounded-full mr-2"></div>
                        <span>To Do (25%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                        <span>In Progress (50%)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                        <span>Done (25%)</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-zinc-800 p-4 rounded-lg">
                    <h4 className="font-medium mb-4">Team Performance</h4>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>John Doe</span>
                          <span>8 tasks</span>
                        </div>
                        <div className="w-full bg-zinc-700 h-2 rounded-full">
                          <div className="bg-amber-500 h-2 rounded-full w-[80%]"></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Sarah Smith</span>
                          <span>12 tasks</span>
                        </div>
                        <div className="w-full bg-zinc-700 h-2 rounded-full">
                          <div className="bg-amber-500 h-2 rounded-full w-full"></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Mike Johnson</span>
                          <span>6 tasks</span>
                        </div>
                        <div className="w-full bg-zinc-700 h-2 rounded-full">
                          <div className="bg-amber-500 h-2 rounded-full w-[60%]"></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Emily Chen</span>
                          <span>9 tasks</span>
                        </div>
                        <div className="w-full bg-zinc-700 h-2 rounded-full">
                          <div className="bg-amber-500 h-2 rounded-full w-[75%]"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </section>

      {/* Dashboard Preview */}
      <section className="container mx-auto px-4 py-20 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Intuitive and Powerful Interface</h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Designed for productivity and ease of use, our interface helps you focus on what matters
          </p>
        </div>
        <DashboardPreview />
      </section>

      {/* Testimonials */}
      <section ref={testimonialsRef} className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={testimonialsInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Trusted by Teams Worldwide</h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            See what our customers have to say about how ProjectPro has transformed their workflow
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={testimonialsInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <TestimonialCard
            quote="ProjectPro has transformed how our team collaborates. The intuitive interface and powerful features have boosted our productivity by 30%."
            author="Sarah Johnson"
            role="Product Manager at TechCorp"
          />
          <TestimonialCard
            quote="The Kanban board and sprint planning features are game-changers. We've never been more organized and efficient."
            author="Michael Chen"
            role="Development Lead at InnovateSoft"
          />
          <TestimonialCard
            quote="The analytics dashboard provides invaluable insights into our team's performance. We can now make data-driven decisions to improve our workflow."
            author="Emily Rodriguez"
            role="Scrum Master at AgileTeam"
          />
          <TestimonialCard
            quote="We've tried many project management tools, but ProjectPro stands out with its balance of power and simplicity. Our entire team adopted it within days."
            author="David Wilson"
            role="CTO at GrowthStartup"
          />
          <TestimonialCard
            quote="The role-based access control is perfect for our agency. Clients can see just what they need while our team has full access to all project details."
            author="Jessica Lee"
            role="Agency Director at CreativeWorks"
          />
          <TestimonialCard
            quote="The real-time chat and task comments have significantly reduced our email volume. All project communication is now in one place."
            author="Robert Kim"
            role="Team Lead at GlobalTech"
          />
        </motion.div>
      </section>

      {/* Pricing Section */}
      <section ref={pricingRef} className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={pricingInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">Choose the plan that fits your team's needs</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={pricingInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto"
        >
          <PricingCard
            title="Starter"
            price="$9"
            description="Perfect for small teams just getting started"
            features={["Up to 5 team members", "5 projects", "Basic Kanban board", "Task management", "Email support"]}
            buttonText="Get Started"
            buttonVariant="outline"
          />

          <PricingCard
            title="Professional"
            price="$29"
            description="Ideal for growing teams with more complex needs"
            features={[
              "Up to 20 team members",
              "Unlimited projects",
              "Advanced Kanban board",
              "Sprint planning",
              "Basic analytics",
              "Priority email support",
            ]}
            buttonText="Get Started"
            buttonVariant="default"
            highlighted={true}
          />

          <PricingCard
            title="Enterprise"
            price="$99"
            description="For large organizations requiring advanced features"
            features={[
              "Unlimited team members",
              "Unlimited projects",
              "Custom workflows",
              "Advanced analytics",
              "API access",
              "SSO integration",
              "Dedicated support",
            ]}
            buttonText="Contact Sales"
            buttonVariant="outline"
          />
        </motion.div>
      </section>

      {/* FAQ Section */}
      <section ref={faqRef} className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={faqInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">Find answers to common questions about ProjectPro</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={faqInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-3xl mx-auto space-y-4"
        >
          <FaqItem
            question="How does the role-based access work?"
            answer="ProjectPro offers three main roles: Admin, Project Manager, and Team Member. Admins have full access to all features and settings. Project Managers can create and manage projects, assign tasks, and view analytics. Team Members can view and update their assigned tasks and participate in project discussions."
          />

          <FaqItem
            question="Can I customize the Kanban board?"
            answer="Yes, you can fully customize your Kanban board. You can add, remove, or rename columns to match your workflow. You can also set up custom filters, add color-coded labels, and configure automation rules for moving tasks between columns."
          />

          <FaqItem
            question="Is there a mobile app available?"
            answer="Yes, ProjectPro is available on iOS and Android devices. The mobile app allows you to view and update tasks, participate in discussions, and receive notifications on the go. All changes sync instantly with the web version."
          />

          <FaqItem
            question="How secure is my data?"
            answer="We take security seriously. All data is encrypted in transit and at rest. We use industry-standard security practices, regular security audits, and offer features like two-factor authentication and single sign-on for enterprise customers."
          />

          <FaqItem
            question="Can I import data from other project management tools?"
            answer="Yes, ProjectPro supports importing data from popular project management tools like Jira, Asana, Trello, and Monday.com. Our import wizard makes it easy to migrate your projects, tasks, and team members."
          />

          <FaqItem
            question="Do you offer a free trial?"
            answer="Yes, we offer a 14-day free trial of our Professional plan with no credit card required. This gives you full access to all features so you can evaluate if ProjectPro is right for your team."
          />
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 relative z-10">
        <div className="bg-gradient-to-r from-zinc-900 to-zinc-800 p-10 rounded-2xl border border-zinc-700 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Project Management?</h2>
          <p className="text-xl text-zinc-400 mb-10 max-w-2xl mx-auto">
            Join thousands of teams who have already improved their workflow with ProjectPro.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup">
              <Button
                size="lg"
                className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
              >
                Get Started Today <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="#" className="group">
              <Button
                size="lg"
                variant="outline"
                className="border-zinc-700 group-hover:border-amber-500 transition-colors"
              >
                Schedule a Demo
              </Button>
            </Link>
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-8">
            <div className="flex items-center">
              <Check className="text-amber-400 mr-2 h-5 w-5" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center">
              <Check className="text-amber-400 mr-2 h-5 w-5" />
              <span>14-day free trial</span>
            </div>
            <div className="flex items-center">
              <Check className="text-amber-400 mr-2 h-5 w-5" />
              <span>Cancel anytime</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-amber-300 to-yellow-600">
                ProjectPro
              </h3>
              <p className="text-zinc-400">Modern project management for modern teams.</p>
              <div className="flex gap-4 mt-4">
                <a href="#" className="text-zinc-400 hover:text-amber-400 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    viewBox="0 0 16 16"
                  >
                    <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z" />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-amber-400 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    viewBox="0 0 16 16"
                  >
                    <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z" />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-amber-400 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    viewBox="0 0 16 16"
                  >
                    <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z" />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-amber-400 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    viewBox="0 0 16 16"
                  >
                    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
                  </svg>
                </a>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-zinc-400">
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Integrations
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Roadmap
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-zinc-400">
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Community
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Support
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-zinc-400">
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-amber-400 transition-colors">
                    Legal
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-zinc-800 mt-12 pt-8 text-center text-zinc-500">
            <p>© 2025 ProjectPro. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Scroll to top button */}
      {showScrollTop && (
        <motion.button
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5 }}
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 bg-amber-500 text-black p-3 rounded-full shadow-lg z-50 hover:bg-amber-600 transition-colors"
        >
          <ArrowUp className="h-6 w-6" />
        </motion.button>
      )}
    </div>
  )
}
