"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import Link from "next/link"
import { ParticleBackground } from "@/components/landing/particle-background"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { motion } from "framer-motion"
import { Check, Loader2 } from "lucide-react"

export default function SignupPage() {
  const router = useRouter()
  const { login } = useAuth()
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [role, setRole] = useState("team_member")
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState(1)

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      login(email, name, role as any)
      router.push("/dashboard")
    }, 1500)
  }

  const nextStep = () => {
    setStep(2)
  }

  const prevStep = () => {
    setStep(1)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-black to-zinc-900 p-4">
      <ParticleBackground />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="w-full border-zinc-800 bg-zinc-900/80 backdrop-blur-sm overflow-hidden">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Create an account</CardTitle>
            <CardDescription>Sign up to get started with ProjectPro</CardDescription>
          </CardHeader>
          <form onSubmit={handleSignup}>
            <CardContent className="space-y-4">
              {step === 1 ? (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4"
                >
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="bg-zinc-800 border-zinc-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-zinc-800 border-zinc-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-zinc-800 border-zinc-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                      className="bg-zinc-800 border-zinc-700"
                    />
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4"
                >
                  <div className="space-y-2">
                    <Label>Select your role</Label>
                    <RadioGroup value={role} onValueChange={setRole} className="space-y-3">
                      <div className="flex items-center space-x-2 bg-zinc-800 p-3 rounded-md border border-zinc-700 cursor-pointer hover:border-amber-500 transition-colors">
                        <RadioGroupItem value="admin" id="admin" className="text-amber-500" />
                        <Label htmlFor="admin" className="flex-1 cursor-pointer">
                          <div className="font-medium">Admin</div>
                          <div className="text-xs text-zinc-400">Full access to all projects and settings</div>
                        </Label>
                        {role === "admin" && <Check className="h-4 w-4 text-amber-500" />}
                      </div>
                      <div className="flex items-center space-x-2 bg-zinc-800 p-3 rounded-md border border-zinc-700 cursor-pointer hover:border-amber-500 transition-colors">
                        <RadioGroupItem value="project_manager" id="project_manager" className="text-amber-500" />
                        <Label htmlFor="project_manager" className="flex-1 cursor-pointer">
                          <div className="font-medium">Project Manager</div>
                          <div className="text-xs text-zinc-400">Create and manage projects, assign tasks</div>
                        </Label>
                        {role === "project_manager" && <Check className="h-4 w-4 text-amber-500" />}
                      </div>
                      <div className="flex items-center space-x-2 bg-zinc-800 p-3 rounded-md border border-zinc-700 cursor-pointer hover:border-amber-500 transition-colors">
                        <RadioGroupItem value="team_member" id="team_member" className="text-amber-500" />
                        <Label htmlFor="team_member" className="flex-1 cursor-pointer">
                          <div className="font-medium">Team Member</div>
                          <div className="text-xs text-zinc-400">Work on assigned tasks and projects</div>
                        </Label>
                        {role === "team_member" && <Check className="h-4 w-4 text-amber-500" />}
                      </div>
                    </RadioGroup>
                  </div>
                </motion.div>
              )}
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              {step === 1 ? (
                <Button
                  type="button"
                  onClick={nextStep}
                  className="w-full bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
                >
                  Continue
                </Button>
              ) : (
                <div className="flex flex-col w-full gap-2">
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating account...
                      </>
                    ) : (
                      "Create account"
                    )}
                  </Button>
                  <Button type="button" variant="outline" onClick={prevStep} className="w-full border-zinc-700">
                    Back
                  </Button>
                </div>
              )}
              <div className="text-center text-sm text-zinc-400">
                Already have an account?{" "}
                <Link href="/login" className="text-amber-400 hover:underline">
                  Login
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </motion.div>
    </div>
  )
}
