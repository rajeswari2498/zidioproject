"use client"

import { useProjects } from "@/hooks/use-projects"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

export function ProjectsOverview() {
  const { projects } = useProjects()

  // Get the 5 most recent projects
  const recentProjects = [...projects]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5)

  return (
    <div className="space-y-4">
      {recentProjects.length > 0 ? (
        recentProjects.map((project) => (
          <Link key={project.id} href={`/dashboard/projects/${project.id}`} className="block">
            <div className="p-3 rounded-md bg-zinc-800 hover:bg-zinc-700 transition-colors">
              <div className="flex justify-between items-start mb-2">
                <div className="font-medium">{project.name}</div>
                <Badge
                  variant={
                    project.status === "active" ? "default" : project.status === "completed" ? "outline" : "secondary"
                  }
                  className={
                    project.status === "active"
                      ? "bg-green-500 text-black"
                      : project.status === "completed"
                        ? "border-green-500 text-green-500"
                        : "bg-amber-500 text-black"
                  }
                >
                  {project.status}
                </Badge>
              </div>
              <div className="text-xs text-zinc-400 mb-2">
                {project.tasks.length} tasks · Due {new Date(project.dueDate).toLocaleDateString()}
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>Progress</span>
                  <span>{project.progress}%</span>
                </div>
                <Progress value={project.progress} className="h-1" />
              </div>
            </div>
          </Link>
        ))
      ) : (
        <div className="text-center py-6 text-zinc-400">
          No projects found. Create your first project to get started.
        </div>
      )}

      {recentProjects.length > 0 && (
        <Link href="/dashboard/projects" className="block text-center text-sm text-amber-400 hover:underline">
          View all projects
        </Link>
      )}
    </div>
  )
}
