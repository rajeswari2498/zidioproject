"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useEffect, useState } from "react"

type Activity = {
  id: string
  user: {
    name: string
    avatar: string
  }
  action: string
  target: string
  timestamp: Date
}

export function ActivityFeed() {
  const [activities, setActivities] = useState<Activity[]>([])

  useEffect(() => {
    // In a real app, this would fetch from an API
    const mockActivities: Activity[] = [
      {
        id: "1",
        user: {
          name: "John Doe",
          avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
        },
        action: "created",
        target: "Website Redesign project",
        timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      },
      {
        id: "2",
        user: {
          name: "Sarah Smith",
          avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
        },
        action: "completed",
        target: "Design homepage mockup task",
        timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      },
      {
        id: "3",
        user: {
          name: "Mike Johnson",
          avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
        },
        action: "commented on",
        target: "Fix navigation bug task",
        timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      },
      {
        id: "4",
        user: {
          name: "Emily Chen",
          avatar: "https://ui-avatars.com/api/?name=Emily+Chen&background=random",
        },
        action: "assigned",
        target: "Implement user authentication to Alex",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      },
      {
        id: "5",
        user: {
          name: "David Wilson",
          avatar: "https://ui-avatars.com/api/?name=David+Wilson&background=random",
        },
        action: "updated",
        target: "Mobile App Development project status",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
      },
    ]

    setActivities(mockActivities)
  }, [])

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)

    let interval = seconds / 31536000
    if (interval > 1) return Math.floor(interval) + " years ago"

    interval = seconds / 2592000
    if (interval > 1) return Math.floor(interval) + " months ago"

    interval = seconds / 86400
    if (interval > 1) return Math.floor(interval) + " days ago"

    interval = seconds / 3600
    if (interval > 1) return Math.floor(interval) + " hours ago"

    interval = seconds / 60
    if (interval > 1) return Math.floor(interval) + " minutes ago"

    return Math.floor(seconds) + " seconds ago"
  }

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={activity.user.avatar || "/placeholder.svg"} alt={activity.user.name} />
            <AvatarFallback>{activity.user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <p className="text-sm">
              <span className="font-medium">{activity.user.name}</span>{" "}
              <span className="text-zinc-400">{activity.action}</span>{" "}
              <span className="font-medium">{activity.target}</span>
            </p>
            <p className="text-xs text-zinc-500">{formatTimeAgo(activity.timestamp)}</p>
          </div>
        </div>
      ))}
    </div>
  )
}
