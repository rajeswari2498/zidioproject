"use client"

import { useAuth } from "@/components/auth-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"

interface RoleSwitcherProps {
  isCollapsed?: boolean
}

export function RoleSwitcher({ isCollapsed = false }: RoleSwitcherProps) {
  const { user, setUserRole } = useAuth()

  if (!user) return null

  return (
    <Select value={user.role} onValueChange={(value) => setUserRole(value as any)}>
      <SelectTrigger className={cn("h-7 text-xs bg-zinc-800 border-zinc-700", isCollapsed ? "hidden" : "w-full")}>
        <SelectValue placeholder="Select role" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="admin">Admin</SelectItem>
        <SelectItem value="project_manager">Project Manager</SelectItem>
        <SelectItem value="team_member">Team Member</SelectItem>
      </SelectContent>
    </Select>
  )
}
