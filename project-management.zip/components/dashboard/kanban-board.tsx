"use client"

import { useState } from "react"
import { DndProvider, useDrop } from "react-dnd"
import { HTML5Backend } from "react-dnd-html5-backend"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { useTasks } from "@/hooks/use-tasks"
import { KanbanCard } from "@/components/projects/kanban-card"
import { CreateTaskDialog } from "@/components/tasks/create-task-dialog"

interface KanbanColumnProps {
  title: string
  tasks: any[]
  status: string
  onDrop: (item: any, status: string) => void
  onAddTask: (status: string) => void
}

function KanbanColumn({ title, tasks, status, onDrop, onAddTask }: KanbanColumnProps) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: "task",
    drop: (item: any) => onDrop(item, status),
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }))

  return (
    <div
      ref={drop}
      className={`bg-zinc-900/30 rounded-md p-3 border ${isOver ? "border-amber-500" : "border-zinc-800"}`}
    >
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-medium">{title}</h3>
        <div className="flex items-center gap-1">
          <Badge className="bg-zinc-700">{tasks.length}</Badge>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-zinc-400 hover:text-white"
            onClick={() => onAddTask(status)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="space-y-2 min-h-[100px]">
        {tasks.map((task) => (
          <KanbanCard key={task.id} task={task} />
        ))}
        {tasks.length === 0 && (
          <div className="text-center py-4 text-zinc-500 text-sm border border-dashed border-zinc-800 rounded-md">
            No tasks
          </div>
        )}
      </div>
    </div>
  )
}

export function KanbanBoard() {
  const { tasks, updateTask } = useTasks()
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedStatus, setSelectedStatus] = useState("To Do")

  // Get the 3 most recent tasks for each status
  const todoTasks = tasks.filter((task) => task.status === "To Do").slice(0, 3)
  const inProgressTasks = tasks.filter((task) => task.status === "In Progress").slice(0, 3)
  const doneTasks = tasks.filter((task) => task.status === "Done").slice(0, 3)

  const handleDrop = (task: any, newStatus: string) => {
    updateTask(task.id, { ...task, status: newStatus })
  }

  const handleAddTask = (status: string) => {
    setSelectedStatus(status)
    setIsCreateDialogOpen(true)
  }

  return (
    <Card className="border-zinc-800 bg-zinc-900/50">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle>Current Sprint</CardTitle>
        <Button
          variant="outline"
          size="sm"
          className="border-zinc-700"
          onClick={() => {
            setSelectedStatus("To Do")
            setIsCreateDialogOpen(true)
          }}
        >
          <Plus className="h-4 w-4 mr-2" /> Add Task
        </Button>
      </CardHeader>
      <CardContent>
        <DndProvider backend={HTML5Backend}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KanbanColumn
              title="To Do"
              status="To Do"
              tasks={todoTasks}
              onDrop={handleDrop}
              onAddTask={handleAddTask}
            />
            <KanbanColumn
              title="In Progress"
              status="In Progress"
              tasks={inProgressTasks}
              onDrop={handleDrop}
              onAddTask={handleAddTask}
            />
            <KanbanColumn title="Done" status="Done" tasks={doneTasks} onDrop={handleDrop} onAddTask={handleAddTask} />
          </div>
        </DndProvider>
      </CardContent>

      <CreateTaskDialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen} defaultStatus={selectedStatus} />
    </Card>
  )
}
