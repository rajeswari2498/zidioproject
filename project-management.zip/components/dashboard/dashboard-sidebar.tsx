"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import {
  BarChart,
  CheckSquare,
  ChevronLeft,
  ChevronRight,
  Folder,
  Home,
  Settings,
  Users,
  Calendar,
  Search,
} from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { RoleSwitcher } from "@/components/dashboard/role-switcher"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useIsMobile } from "@/hooks/use-mobile"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function DashboardSidebar() {
  const pathname = usePathname()
  const { user } = useAuth()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileOpen, setIsMobileOpen] = useState(false)
  const isMobile = useIsMobile()

  useEffect(() => {
    // Close mobile sidebar when navigating
    setIsMobileOpen(false)
  }, [pathname])

  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  const sidebarVariants = {
    expanded: { width: "240px" },
    collapsed: { width: "72px" },
  }

  const mobileMenuVariants = {
    open: { x: 0 },
    closed: { x: "-100%" },
  }

  const menuItems = [
    { path: "/dashboard", icon: <Home className="h-5 w-5" />, label: "Dashboard" },
    { path: "/dashboard/projects", icon: <Folder className="h-5 w-5" />, label: "Projects" },
    { path: "/dashboard/tasks", icon: <CheckSquare className="h-5 w-5" />, label: "Tasks" },
    { path: "/dashboard/analytics", icon: <BarChart className="h-5 w-5" />, label: "Analytics" },
    { path: "/dashboard/calendar", icon: <Calendar className="h-5 w-5" />, label: "Calendar" },
    // Removed Chat button as requested
  ]

  // Admin and Project Manager only menu items
  const adminMenuItems = [
    { path: "/dashboard/team", icon: <Users className="h-5 w-5" />, label: "Team" },
    { path: "/dashboard/settings", icon: <Settings className="h-5 w-5" />, label: "Settings" },
  ]

  const renderMenuItems = (items: typeof menuItems) => {
    return items.map((item) => (
      <TooltipProvider key={item.path} delayDuration={300}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Link
              href={item.path}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md transition-colors",
                isActive(item.path)
                  ? "bg-amber-500/20 text-amber-400"
                  : "text-zinc-400 hover:text-white hover:bg-zinc-800",
              )}
            >
              {item.icon}
              <AnimatePresence initial={false}>
                {(!isCollapsed || isMobile) && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: "auto" }}
                    exit={{ opacity: 0, width: 0 }}
                    className="whitespace-nowrap overflow-hidden"
                  >
                    {item.label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          </TooltipTrigger>
          <TooltipContent side="right" className={cn("bg-zinc-800", !isCollapsed && "hidden")}>
            {item.label}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    ))
  }

  // Mobile sidebar toggle button
  const MobileToggle = () => (
    <Button
      variant="outline"
      size="icon"
      className="md:hidden fixed top-4 left-4 z-50 bg-zinc-900 border-zinc-700"
      onClick={() => setIsMobileOpen(!isMobileOpen)}
    >
      <Search className="h-5 w-5" />
    </Button>
  )

  // Desktop sidebar
  const DesktopSidebar = () => (
    <motion.div
      variants={sidebarVariants}
      initial="expanded"
      animate={isCollapsed ? "collapsed" : "expanded"}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className={cn(
        "hidden md:flex flex-col h-screen border-r border-zinc-800 bg-zinc-900 overflow-hidden",
        isCollapsed ? "w-[72px]" : "w-[240px]",
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-zinc-800">
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="h-8 w-8 rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 flex items-center justify-center flex-shrink-0">
            <span className="text-lg font-bold text-black">P</span>
          </div>
          <AnimatePresence initial={false}>
            {!isCollapsed && (
              <motion.span
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                className="font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-300 to-yellow-600 whitespace-nowrap"
              >
                ProjectPro
              </motion.span>
            )}
          </AnimatePresence>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="text-zinc-400 hover:text-white"
        >
          {isCollapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>

      <div className="flex-1 py-4 overflow-y-auto">
        <nav className="space-y-1 px-2">
          {renderMenuItems(menuItems)}

          {(user?.role === "admin" || user?.role === "project_manager") && (
            <>
              <div className="pt-4 pb-2 px-3">
                <AnimatePresence initial={false}>
                  {!isCollapsed && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="text-xs font-semibold text-zinc-500 uppercase"
                    >
                      Administration
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              {renderMenuItems(adminMenuItems)}
            </>
          )}
        </nav>
      </div>

      <div className="p-4 border-t border-zinc-800">
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.name} />
            <AvatarFallback>{user?.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <AnimatePresence initial={false}>
            {!isCollapsed && (
              <motion.div
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                className="flex flex-col min-w-0 overflow-hidden"
              >
                <span className="font-medium truncate">{user?.name}</span>
                <RoleSwitcher isCollapsed={isCollapsed} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  )

  // Mobile sidebar
  const MobileSidebar = () => (
    <>
      <MobileToggle />
      <AnimatePresence>
        {isMobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black z-40 md:hidden"
              onClick={() => setIsMobileOpen(false)}
            />
            <motion.div
              variants={mobileMenuVariants}
              initial="closed"
              animate="open"
              exit="closed"
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="fixed top-0 left-0 bottom-0 w-[240px] bg-zinc-900 z-50 md:hidden border-r border-zinc-800"
            >
              <div className="flex items-center justify-between p-4 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 flex items-center justify-center">
                    <span className="text-lg font-bold text-black">P</span>
                  </div>
                  <span className="font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-300 to-yellow-600">
                    ProjectPro
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMobileOpen(false)}
                  className="text-zinc-400 hover:text-white"
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
              </div>

              <div className="flex-1 py-4 overflow-y-auto">
                <nav className="space-y-1 px-2">
                  {renderMenuItems(menuItems)}

                  {(user?.role === "admin" || user?.role === "project_manager") && (
                    <>
                      <div className="pt-4 pb-2 px-3">
                        <div className="text-xs font-semibold text-zinc-500 uppercase">Administration</div>
                      </div>
                      {renderMenuItems(adminMenuItems)}
                    </>
                  )}
                </nav>
              </div>

              <div className="p-4 border-t border-zinc-800">
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.name} />
                    <AvatarFallback>{user?.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-medium">{user?.name}</span>
                    <RoleSwitcher isCollapsed={false} />
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )

  return (
    <>
      <DesktopSidebar />
      <MobileSidebar />
    </>
  )
}
