"use client"

import { useTasks } from "@/hooks/use-tasks"
import { Badge } from "@/components/ui/badge"
import { Clock } from "lucide-react"
import Link from "next/link"

export function TasksOverview() {
  const { tasks } = useTasks()

  // Get the 5 most recent tasks assigned to the current user
  const recentTasks = [...tasks]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5)

  return (
    <div className="space-y-4">
      {recentTasks.length > 0 ? (
        recentTasks.map((task) => (
          <Link key={task.id} href={`/dashboard/tasks?id=${task.id}`} className="block">
            <div className="p-3 rounded-md bg-zinc-800 hover:bg-zinc-700 transition-colors">
              <div className="flex justify-between items-start mb-1">
                <div className="font-medium">{task.title}</div>
                <Badge
                  variant={task.priority === "High" ? "default" : task.priority === "Medium" ? "outline" : "secondary"}
                  className={
                    task.priority === "High"
                      ? "bg-red-500 text-white"
                      : task.priority === "Medium"
                        ? "border-amber-500 text-amber-500"
                        : "bg-blue-500 text-white"
                  }
                >
                  {task.priority}
                </Badge>
              </div>
              <div className="text-xs text-zinc-400 mb-2">
                {task.projectName} · {task.type}
              </div>
              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3 text-zinc-400" />
                  <span>Due {new Date(task.dueDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Badge
                    variant="outline"
                    className={
                      task.status === "Done"
                        ? "border-green-500 text-green-500"
                        : task.status === "In Progress"
                          ? "border-blue-500 text-blue-500"
                          : task.status === "Review"
                            ? "border-purple-500 text-purple-500"
                            : "border-zinc-500 text-zinc-500"
                    }
                  >
                    {task.status}
                  </Badge>
                </div>
              </div>
            </div>
          </Link>
        ))
      ) : (
        <div className="text-center py-6 text-zinc-400">
          No tasks assigned to you. Tasks will appear here when assigned.
        </div>
      )}

      {recentTasks.length > 0 && (
        <Link href="/dashboard/tasks" className="block text-center text-sm text-amber-400 hover:underline">
          View all tasks
        </Link>
      )}
    </div>
  )
}
