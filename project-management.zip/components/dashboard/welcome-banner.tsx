"use client"

import { useAuth } from "@/components/auth-provider"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export function WelcomeBanner() {
  const { user } = useAuth()

  if (!user) return null

  return (
    <Card className="border-zinc-800 bg-gradient-to-r from-zinc-900 to-zinc-800 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-64 h-full bg-gradient-to-l from-amber-500/10 to-transparent" />
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h1 className="text-2xl font-bold">Welcome back, {user.name}!</h1>
            <p className="text-zinc-400">
              {user.role === "admin" && "You have full access to all projects and settings."}
              {user.role === "project_manager" && "You can manage projects and assign tasks to team members."}
              {user.role === "team_member" && "You can view and update your assigned tasks."}
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/dashboard/projects">
                <Button variant="outline" className="border-zinc-700">
                  View Projects <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/dashboard/tasks">
                <Button variant="outline" className="border-zinc-700">
                  My Tasks <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
          <div className="hidden md:flex items-center justify-end">
            <div className="flex flex-col items-end gap-2">
              <div className="flex gap-2">
                <div className="bg-zinc-800 rounded-md p-2 text-center w-24">
                  <div className="text-2xl font-bold text-amber-400">5</div>
                  <div className="text-xs text-zinc-400">Active Projects</div>
                </div>
                <div className="bg-zinc-800 rounded-md p-2 text-center w-24">
                  <div className="text-2xl font-bold text-amber-400">12</div>
                  <div className="text-xs text-zinc-400">Tasks</div>
                </div>
              </div>
              <div className="flex gap-2">
                <div className="bg-zinc-800 rounded-md p-2 text-center w-24">
                  <div className="text-2xl font-bold text-amber-400">3</div>
                  <div className="text-xs text-zinc-400">Due Soon</div>
                </div>
                <div className="bg-zinc-800 rounded-md p-2 text-center w-24">
                  <div className="text-2xl font-bold text-amber-400">85%</div>
                  <div className="text-xs text-zinc-400">Completion</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
