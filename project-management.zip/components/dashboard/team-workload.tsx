"use client"

import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useEffect, useState } from "react"

type TeamMember = {
  id: string
  name: string
  avatar: string
  role: string
  workload: number
  tasks: {
    total: number
    completed: number
  }
}

export function TeamWorkload() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])

  useEffect(() => {
    // In a real app, this would fetch from an API
    const mockTeamMembers: TeamMember[] = [
      {
        id: "1",
        name: "John Doe",
        avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
        role: "Frontend Developer",
        workload: 85,
        tasks: {
          total: 12,
          completed: 8,
        },
      },
      {
        id: "2",
        name: "Sarah Smith",
        avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
        role: "UI/UX Designer",
        workload: 60,
        tasks: {
          total: 8,
          completed: 5,
        },
      },
      {
        id: "3",
        name: "Mike Johnson",
        avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
        role: "Backend Developer",
        workload: 75,
        tasks: {
          total: 10,
          completed: 7,
        },
      },
      {
        id: "4",
        name: "Emily Chen",
        avatar: "https://ui-avatars.com/api/?name=Emily+Chen&background=random",
        role: "Project Manager",
        workload: 45,
        tasks: {
          total: 6,
          completed: 3,
        },
      },
      {
        id: "5",
        name: "David Wilson",
        avatar: "https://ui-avatars.com/api/?name=David+Wilson&background=random",
        role: "QA Engineer",
        workload: 90,
        tasks: {
          total: 15,
          completed: 12,
        },
      },
    ]

    setTeamMembers(mockTeamMembers)
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teamMembers.map((member) => (
          <div key={member.id} className="p-4 rounded-md bg-zinc-800">
            <div className="flex items-center gap-3 mb-4">
              <Avatar>
                <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">{member.name}</div>
                <div className="text-xs text-zinc-400">{member.role}</div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>Workload</span>
                  <span
                    className={
                      member.workload > 80 ? "text-red-400" : member.workload > 60 ? "text-amber-400" : "text-green-400"
                    }
                  >
                    {member.workload}%
                  </span>
                </div>
                <Progress
                  value={member.workload}
                  className="h-1.5"
                  indicatorClassName={
                    member.workload > 80 ? "bg-red-500" : member.workload > 60 ? "bg-amber-500" : "bg-green-500"
                  }
                />
              </div>
              <div className="flex justify-between text-xs text-zinc-400">
                <span>
                  Tasks: {member.tasks.completed}/{member.tasks.total}
                </span>
                <span>{Math.round((member.tasks.completed / member.tasks.total) * 100)}% complete</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
