"use client"

import { useEffect, useState } from "react"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { useProjects } from "@/hooks/use-projects"

interface ProjectCompletionChartProps {
  timeRange?: number
  projectId?: string
}

export function ProjectCompletionChart({ timeRange = 30, projectId }: ProjectCompletionChartProps) {
  const [data, setData] = useState<any[]>([])
  const { projects } = useProjects()

  useEffect(() => {
    // Generate mock data for project completion over time
    const generateData = () => {
      const result = []
      const now = new Date()
      const filteredProjects = projectId ? projects.filter((p) => p.id === projectId) : projects

      for (let i = timeRange; i >= 0; i--) {
        const date = new Date(now)
        date.setDate(date.getDate() - i)

        const entry: any = {
          date: date.toISOString().split("T")[0],
        }

        filteredProjects.forEach((project) => {
          // Simulate progress increasing over time
          const progress = Math.min(
            100,
            Math.max(0, project.progress - Math.floor(Math.random() * 5) * (i / timeRange) * 100),
          )
          entry[project.name] = progress
        })

        result.push(entry)
      }

      return result
    }

    setData(generateData())
  }, [projects, timeRange, projectId])

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={data}
        margin={{
          top: 10,
          right: 30,
          left: 0,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
        <XAxis dataKey="date" stroke="#666" />
        <YAxis stroke="#666" />
        <Tooltip
          contentStyle={{
            backgroundColor: "#1e1e1e",
            borderColor: "#333",
            color: "#fff",
          }}
        />
        {projects
          .filter((p) => !projectId || p.id === projectId)
          .map((project, index) => (
            <Area
              key={project.id}
              type="monotone"
              dataKey={project.name}
              stroke={getColorByIndex(index)}
              fill={getColorByIndex(index, 0.2)}
            />
          ))}
      </AreaChart>
    </ResponsiveContainer>
  )
}

function getColorByIndex(index: number, opacity = 1) {
  const colors = [
    `rgba(251, 191, 36, ${opacity})`, // amber
    `rgba(59, 130, 246, ${opacity})`, // blue
    `rgba(139, 92, 246, ${opacity})`, // purple
    `rgba(16, 185, 129, ${opacity})`, // green
    `rgba(239, 68, 68, ${opacity})`, // red
    `rgba(236, 72, 153, ${opacity})`, // pink
  ]

  return colors[index % colors.length]
}
