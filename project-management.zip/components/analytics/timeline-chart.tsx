"use client"

import { useEffect, useState } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { useProjects } from "@/hooks/use-projects"

export function TimelineChart() {
  const [data, setData] = useState<any[]>([])
  const { projects } = useProjects()

  useEffect(() => {
    // Generate mock data for project timeline
    const generateData = () => {
      const now = new Date()
      const result = []

      for (let i = 0; i < projects.length; i++) {
        const project = projects[i]
        const startDate = new Date(project.createdAt)
        const endDate = new Date(project.dueDate)

        result.push({
          name: project.name,
          start: startDate.getTime(),
          end: endDate.getTime(),
          duration: endDate.getTime() - startDate.getTime(),
          progress: project.progress,
        })
      }

      return result
    }

    setData(generateData())
  }, [projects])

  // Custom tooltip to display dates
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-zinc-900 p-3 border border-zinc-800 rounded-md">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm text-zinc-400">Start: {new Date(data.start).toLocaleDateString()}</p>
          <p className="text-sm text-zinc-400">End: {new Date(data.end).toLocaleDateString()}</p>
          <p className="text-sm text-amber-400">Progress: {data.progress}%</p>
        </div>
      )
    }

    return null
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        layout="vertical"
        margin={{
          top: 20,
          right: 30,
          left: 100,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#333" horizontal={false} />
        <XAxis
          type="number"
          domain={["dataMin", "dataMax"]}
          tickFormatter={(value) => new Date(value).toLocaleDateString()}
          stroke="#666"
        />
        <YAxis dataKey="name" type="category" stroke="#666" />
        <Tooltip content={<CustomTooltip />} />
        <Bar dataKey="duration" fill="#FBBF24" background={{ fill: "#333" }} radius={[4, 4, 4, 4]} />
      </BarChart>
    </ResponsiveContainer>
  )
}
