"use client"

import { useEffect, useState } from "react"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
import { useTasks } from "@/hooks/use-tasks"

interface TaskDistributionChartProps {
  type?: "status" | "priority" | "type"
  projectId?: string
}

export function TaskDistributionChart({ type = "status", projectId }: TaskDistributionChartProps) {
  const [data, setData] = useState<any[]>([])
  const { tasks } = useTasks()

  useEffect(() => {
    // Filter tasks by project if projectId is provided
    const filteredTasks = projectId ? tasks.filter((task) => task.projectId === projectId) : tasks

    // Group tasks by the specified type
    const groupedTasks = filteredTasks.reduce(
      (acc, task) => {
        const key = type === "status" ? task.status : type === "priority" ? task.priority : task.type

        if (!acc[key]) {
          acc[key] = 0
        }

        acc[key]++
        return acc
      },
      {} as Record<string, number>,
    )

    // Convert to chart data format
    const chartData = Object.entries(groupedTasks).map(([name, value]) => ({
      name,
      value,
    }))

    setData(chartData)
  }, [tasks, type, projectId])

  const COLORS = [
    "#FBBF24", // amber
    "#3B82F6", // blue
    "#8B5CF6", // purple
    "#10B981", // green
    "#EF4444", // red
    "#EC4899", // pink
  ]

  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          contentStyle={{
            backgroundColor: "#1e1e1e",
            borderColor: "#333",
            color: "#fff",
          }}
        />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  )
}
