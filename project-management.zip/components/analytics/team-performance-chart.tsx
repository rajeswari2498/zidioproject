"use client"

import { useEffect, useState } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

interface TeamPerformanceChartProps {
  timeRange?: number
  detailed?: boolean
  projectId?: string
}

export function TeamPerformanceChart({ timeRange = 30, detailed = false, projectId }: TeamPerformanceChartProps) {
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Generate mock data for team performance
    const generateData = () => {
      const teamMembers = ["John Doe", "Sarah Smith", "Mike Johnson", "Emily Chen", "David Wilson"]

      return teamMembers.map((name) => {
        const result: any = {
          name,
          completed: Math.floor(Math.random() * 20) + 5,
          inProgress: Math.floor(Math.random() * 10) + 1,
        }

        if (detailed) {
          result.overdue = Math.floor(Math.random() * 5)
          result.efficiency = Math.floor(Math.random() * 30) + 70
        }

        return result
      })
    }

    setData(generateData())
  }, [timeRange, detailed, projectId])

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
        <XAxis dataKey="name" stroke="#666" />
        <YAxis stroke="#666" />
        <Tooltip
          contentStyle={{
            backgroundColor: "#1e1e1e",
            borderColor: "#333",
            color: "#fff",
          }}
        />
        <Legend />
        <Bar dataKey="completed" stackId="a" fill="#FBBF24" name="Completed" />
        <Bar dataKey="inProgress" stackId="a" fill="#3B82F6" name="In Progress" />
        {detailed && (
          <>
            <Bar dataKey="overdue" stackId="a" fill="#EF4444" name="Overdue" />
            <Bar dataKey="efficiency" fill="#10B981" name="Efficiency %" />
          </>
        )}
      </BarChart>
    </ResponsiveContainer>
  )
}
