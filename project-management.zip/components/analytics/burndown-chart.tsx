"use client"

import { useEffect, useState } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

interface BurndownChartProps {
  sprintId: string
}

export function BurndownChart({ sprintId }: BurndownChartProps) {
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Generate mock data for burndown chart
    const generateData = () => {
      const result = []
      const totalDays = 14 // 2-week sprint
      const totalPoints = 100

      // Ideal burndown is a straight line from total points to 0
      const idealBurndownPerDay = totalPoints / totalDays

      // Actual burndown will fluctuate around the ideal
      let remainingPoints = totalPoints

      for (let day = 0; day <= totalDays; day++) {
        // Ideal points should decrease linearly
        const idealPoints = Math.max(0, totalPoints - idealBurndownPerDay * day)

        // Actual points will vary - sometimes above, sometimes below ideal
        if (day > 0) {
          // On some days, more work gets done than others
          const pointsCompleted =
            day < totalDays * 0.7
              ? Math.random() * 10 + 5 // More work done in first 70% of sprint
              : Math.random() * 5 // Less work done toward the end

          remainingPoints = Math.max(0, remainingPoints - pointsCompleted)
        }

        result.push({
          day,
          ideal: Math.round(idealPoints),
          actual: Math.round(remainingPoints),
        })
      }

      return result
    }

    setData(generateData())
  }, [sprintId])

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
        <XAxis dataKey="day" stroke="#666" />
        <YAxis stroke="#666" />
        <Tooltip
          contentStyle={{
            backgroundColor: "#1e1e1e",
            borderColor: "#333",
            color: "#fff",
          }}
        />
        <Legend />
        <Line
          type="monotone"
          dataKey="ideal"
          stroke="#8B5CF6"
          strokeDasharray="5 5"
          name="Ideal Burndown"
          dot={false}
        />
        <Line type="monotone" dataKey="actual" stroke="#FBBF24" name="Actual Burndown" activeDot={{ r: 8 }} />
      </LineChart>
    </ResponsiveContainer>
  )
}
