"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { useTasks } from "@/hooks/use-tasks"
import { useProjects } from "@/hooks/use-projects"
import type { Task } from "@/types/task"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, Paperclip, Send, Smile } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

interface TaskDialogProps {
  task: Task
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function TaskDialog({ task, open, onOpenChange }: TaskDialogProps) {
  const { updateTask } = useTasks()
  const { projects, getProjectById } = useProjects()

  const [title, setTitle] = useState(task.title)
  const [description, setDescription] = useState(task.description)
  const [type, setType] = useState(task.type)
  const [priority, setPriority] = useState(task.priority)
  const [status, setStatus] = useState(task.status)
  const [selectedProject, setSelectedProject] = useState(task.projectId)
  const [date, setDate] = useState<Date>(new Date(task.dueDate))
  const [comment, setComment] = useState("")

  // Mock comments for the task
  const [comments, setComments] = useState([
    {
      id: "1",
      text: "I think we should prioritize this for the next sprint.",
      user: {
        name: "Sarah Smith",
        avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
      },
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    },
    {
      id: "2",
      text: "I've started working on this. Should be done by tomorrow.",
      user: {
        name: "John Doe",
        avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
      },
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 12), // 12 hours ago
    },
  ])

  // Mock activity for the task
  const activities = [
    {
      id: "1",
      action: "created",
      user: {
        name: "Mike Johnson",
        avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
      },
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48), // 2 days ago
    },
    {
      id: "2",
      action: "changed status from 'To Do' to 'In Progress'",
      user: {
        name: "John Doe",
        avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
      },
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    },
    {
      id: "3",
      action: "assigned to John Doe",
      user: {
        name: "Sarah Smith",
        avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
      },
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 12), // 12 hours ago
    },
  ]

  const handleSave = () => {
    updateTask(task.id, {
      title,
      description,
      type: type as any,
      priority: priority as any,
      status: status as any,
      projectId: selectedProject,
      dueDate: date.toISOString(),
    })

    onOpenChange(false)
  }

  const handleAddComment = () => {
    if (!comment.trim()) return

    const newComment = {
      id: Date.now().toString(),
      text: comment,
      user: {
        name: "You",
        avatar: "https://ui-avatars.com/api/?name=You&background=random",
      },
      timestamp: new Date(),
    }

    setComments([...comments, newComment])
    setComment("")
  }

  const project = getProjectById(selectedProject)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] bg-zinc-900 border-zinc-800 max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">{task.title}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="details" className="mt-4">
          <TabsList className="bg-zinc-800 border-zinc-700 p-1">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="comments">Comments</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4 mt-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="bg-zinc-800 border-zinc-700 min-h-[150px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Attachments</Label>
                  <div className="p-4 border border-dashed border-zinc-700 rounded-md text-center">
                    <Paperclip className="h-6 w-6 mx-auto mb-2 text-zinc-500" />
                    <p className="text-sm text-zinc-400">Drop files here or click to upload</p>
                    <Button variant="outline" className="mt-2 border-zinc-700">
                      Upload Files
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="To Do">To Do</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Review">Review</SelectItem>
                      <SelectItem value="Done">Done</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Bug">Bug</SelectItem>
                      <SelectItem value="Feature">Feature</SelectItem>
                      <SelectItem value="Epic">Epic</SelectItem>
                      <SelectItem value="Task">Task</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="Low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Due Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal bg-zinc-800 border-zinc-700",
                          !date && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-zinc-900 border-zinc-800">
                      <Calendar mode="single" selected={date} onSelect={(date) => date && setDate(date)} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="project">Project</Label>
                  <Select value={selectedProject} onValueChange={setSelectedProject}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Assignee</Label>
                  <div className="flex items-center gap-2 p-2 bg-zinc-800 rounded-md border border-zinc-700">
                    <Avatar>
                      <AvatarImage src={task.assignee.avatar || "/placeholder.svg"} alt={task.assignee.name} />
                      <AvatarFallback>{task.assignee.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="text-sm">{task.assignee.name}</div>
                      <div className="text-xs text-zinc-400">{task.assignee.role}</div>
                    </div>
                    <Button variant="outline" size="sm" className="border-zinc-700">
                      Change
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-blue-500 text-white">frontend</Badge>
                    <Badge className="bg-green-500 text-white">ui</Badge>
                    <Badge className="bg-purple-500 text-white">design</Badge>
                    <Button variant="outline" size="sm" className="h-6 border-zinc-700">
                      + Add
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-zinc-800">
              <Button variant="outline" className="border-zinc-700" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} className="bg-amber-500 hover:bg-amber-600 text-black">
                Save Changes
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="comments" className="space-y-4 mt-4">
            <div className="space-y-4 max-h-[400px] overflow-y-auto p-2">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={comment.user.avatar || "/placeholder.svg"} alt={comment.user.name} />
                    <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-zinc-800 p-3 rounded-md">
                      <div className="flex justify-between items-center mb-1">
                        <div className="font-medium text-sm">{comment.user.name}</div>
                        <div className="text-xs text-zinc-400">{format(comment.timestamp, "MMM d, h:mm a")}</div>
                      </div>
                      <p className="text-sm">{comment.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-2 pt-4 border-t border-zinc-800">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg" alt="You" />
                <AvatarFallback>Y</AvatarFallback>
              </Avatar>
              <div className="flex-1 flex gap-2">
                <Input
                  placeholder="Add a comment..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                />
                <Button variant="outline" size="icon" className="h-10 w-10 border-zinc-700">
                  <Smile className="h-5 w-5" />
                </Button>
                <Button onClick={handleAddComment} className="bg-amber-500 hover:bg-amber-600 text-black">
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-4 mt-4">
            <div className="space-y-4 max-h-[400px] overflow-y-auto p-2">
              {activities.map((activity) => (
                <div key={activity.id} className="flex gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={activity.user.avatar || "/placeholder.svg"} alt={activity.user.name} />
                    <AvatarFallback>{activity.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="p-3 rounded-md bg-zinc-800/50">
                      <div className="flex justify-between items-center">
                        <div className="text-sm">
                          <span className="font-medium">{activity.user.name}</span>{" "}
                          <span className="text-zinc-400">{activity.action}</span>
                        </div>
                        <div className="text-xs text-zinc-400">{format(activity.timestamp, "MMM d, h:mm a")}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
