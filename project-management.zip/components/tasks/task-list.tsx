"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TaskDialog } from "@/components/tasks/task-dialog"
import { CreateTaskDialog } from "@/components/tasks/create-task-dialog"
import { useTasks } from "@/hooks/use-tasks"
import { useAuth } from "@/components/auth-provider"
import type { Task } from "@/types/task"
import { Search, Plus, MoreHorizontal, Filter, ArrowUpDown, Trash2, Edit, Eye } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

export function TaskList() {
  const { tasks, removeTask, updateTask } = useTasks()
  const { user } = useAuth()
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [sortBy, setSortBy] = useState("dueDate")
  const [sortOrder, setSortOrder] = useState("asc")
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false)
  const [isCreateTaskDialogOpen, setIsCreateTaskDialogOpen] = useState(false)

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task)
    setIsTaskDialogOpen(true)
  }

  const handleTaskDelete = (taskId: string) => {
    if (user?.role === "admin" || user?.role === "project_manager") {
      removeTask(taskId)
      toast({
        title: "Task deleted",
        description: "The task has been deleted successfully",
      })
    } else {
      toast({
        title: "Permission denied",
        description: "You don't have permission to delete tasks",
        variant: "destructive",
      })
    }
  }

  const handleTaskStatusChange = (taskId: string, completed: boolean) => {
    const task = tasks.find((t) => t.id === taskId)
    if (task) {
      updateTask({
        ...task,
        status: completed ? "completed" : "in_progress",
      })
    }
  }

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || task.status === statusFilter
    const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter

    return matchesSearch && matchesStatus && matchesPriority
  })

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === "dueDate") {
      const dateA = new Date(a.dueDate).getTime()
      const dateB = new Date(b.dueDate).getTime()
      return sortOrder === "asc" ? dateA - dateB : dateB - dateA
    } else if (sortBy === "priority") {
      const priorityOrder = { low: 1, medium: 2, high: 3 }
      const priorityA = priorityOrder[a.priority as keyof typeof priorityOrder]
      const priorityB = priorityOrder[b.priority as keyof typeof priorityOrder]
      return sortOrder === "asc" ? priorityA - priorityB : priorityB - priorityA
    } else {
      // Sort by title
      return sortOrder === "asc" ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title)
    }
  })

  const toggleSortOrder = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "todo":
        return "bg-zinc-500"
      case "in_progress":
        return "bg-blue-500"
      case "review":
        return "bg-amber-500"
      case "completed":
        return "bg-green-500"
      default:
        return "bg-zinc-500"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low":
        return "bg-blue-500"
      case "medium":
        return "bg-amber-500"
      case "high":
        return "bg-red-500"
      default:
        return "bg-zinc-500"
    }
  }

  return (
    <div className="space-y-4">
      <Card className="border-zinc-800 bg-zinc-900/50">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div className="space-y-1">
            <CardTitle>Tasks</CardTitle>
            <CardDescription>Manage and track your tasks</CardDescription>
          </div>
          <Button
            onClick={() => setIsCreateTaskDialogOpen(true)}
            className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
          >
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-400" />
                <Input
                  placeholder="Search tasks..."
                  className="pl-10 bg-zinc-800 border-zinc-700"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-zinc-400" />
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[130px] bg-zinc-800 border-zinc-700">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="todo">To Do</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="review">In Review</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-zinc-400" />
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-[130px] bg-zinc-800 border-zinc-700">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <ArrowUpDown className="h-4 w-4 text-zinc-400" />
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[130px] bg-zinc-800 border-zinc-700">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dueDate">Due Date</SelectItem>
                    <SelectItem value="priority">Priority</SelectItem>
                    <SelectItem value="title">Title</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon" onClick={toggleSortOrder} className="h-9 w-9 border-zinc-700">
                  <ArrowUpDown className={cn("h-4 w-4", sortOrder === "desc" && "rotate-180")} />
                </Button>
              </div>
            </div>
          </div>

          <div className="rounded-md border border-zinc-800 overflow-hidden">
            <div className="grid grid-cols-12 bg-zinc-800 p-4 text-xs font-medium text-zinc-400 uppercase">
              <div className="col-span-1"></div>
              <div className="col-span-5">Task</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-2">Due Date</div>
              <div className="col-span-2">Actions</div>
            </div>
            <div className="divide-y divide-zinc-800">
              {sortedTasks.length > 0 ? (
                sortedTasks.map((task) => (
                  <div key={task.id} className="grid grid-cols-12 p-4 items-center hover:bg-zinc-800/50">
                    <div className="col-span-1">
                      <Checkbox
                        checked={task.status === "completed"}
                        onCheckedChange={(checked) => handleTaskStatusChange(task.id, checked as boolean)}
                        className="data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
                      />
                    </div>
                    <div className="col-span-5">
                      <div className="flex items-center gap-3">
                        <div>
                          <p className={cn("font-medium", task.status === "completed" && "line-through text-zinc-500")}>
                            {task.title}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className={cn("text-xs", getPriorityColor(task.priority))}>
                              {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                            </Badge>
                            <span className="text-xs text-zinc-400">{task.projectName}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-span-2">
                      <Badge className={cn("text-xs", getStatusColor(task.status))}>
                        {task.status === "todo" && "To Do"}
                        {task.status === "in_progress" && "In Progress"}
                        {task.status === "review" && "In Review"}
                        {task.status === "completed" && "Completed"}
                      </Badge>
                    </div>
                    <div className="col-span-2 text-sm">{format(new Date(task.dueDate), "MMM d, yyyy")}</div>
                    <div className="col-span-2 flex space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 border-zinc-700"
                        onClick={() => handleTaskClick(task)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="icon" className="h-8 w-8 border-zinc-700">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-zinc-800 border-zinc-700">
                          <DropdownMenuItem
                            className="cursor-pointer flex items-center"
                            onClick={() => handleTaskClick(task)}
                          >
                            <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                          {(user?.role === "admin" || user?.role === "project_manager") && (
                            <DropdownMenuItem
                              className="cursor-pointer flex items-center text-red-500 focus:text-red-500"
                              onClick={() => handleTaskDelete(task.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" /> Delete
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-zinc-400">No tasks found matching your search criteria</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedTask && <TaskDialog task={selectedTask} open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen} />}

      <CreateTaskDialog open={isCreateTaskDialogOpen} onOpenChange={setIsCreateTaskDialogOpen} />
    </div>
  )
}
