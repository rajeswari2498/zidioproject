import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { QuoteIcon } from "lucide-react"

interface TestimonialCardProps {
  quote: string
  author: string
  role: string
}

export function TestimonialCard({ quote, author, role }: TestimonialCardProps) {
  return (
    <Card className="border-zinc-800 bg-zinc-900/30 backdrop-blur-sm hover:border-amber-800/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(251,191,36,0.1)]">
      <CardContent className="pt-6 relative">
        <QuoteIcon className="absolute top-6 left-0 h-6 w-6 text-amber-400/30" />
        <p className="text-zinc-300 pl-8">{quote}</p>
      </CardContent>
      <CardFooter className="flex flex-col items-start">
        <p className="font-semibold">{author}</p>
        <p className="text-zinc-400 text-sm">{role}</p>
      </CardFooter>
    </Card>
  )
}
