"use client"

import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"

interface FeatureCardProps {
  icon: React.ReactNode
  title: string
  description: string
}

export function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(251, 191, 36, 0.1)" }}
      transition={{ duration: 0.2 }}
    >
      <Card className="border-zinc-800 bg-zinc-900/30 backdrop-blur-sm hover:border-amber-800/50 transition-all duration-300">
        <CardHeader className="pb-2">
          <div className="mb-2">{icon}</div>
          <CardTitle className="text-xl">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-zinc-400 text-sm">{description}</CardDescription>
        </CardContent>
      </Card>
    </motion.div>
  )
}
