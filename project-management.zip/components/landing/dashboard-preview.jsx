"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"

export function DashboardPreview() {
  const [currentImage, setCurrentImage] = useState(0)
  const images = [
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-ycRzoJ8RKwo9NBBnpdCYNqus2dJsJf.png",
      alt: "Dashboard Overview",
      title: "Dashboard Overview",
      description: "Get a bird's eye view of all your projects and tasks",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wEYu7TOzpjFGIcHySqMBTuJPXFQAs8.png",
      alt: "Kanban Board",
      title: "Kanban Board",
      description: "Visualize your workflow with customizable boards",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pIqHrANyPANubHecoioTX0PMY3Hs9Z.png",
      alt: "Analytics Dashboard",
      title: "Analytics Dashboard",
      description: "Make data-driven decisions with comprehensive analytics",
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % images.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [images.length])

  return (
    <Card className="border-zinc-800 bg-zinc-900/30 backdrop-blur-sm overflow-hidden">
      <div className="relative w-full h-[500px] rounded-md overflow-hidden">
        {images.map((image, index) => (
          <motion.div
            key={index}
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: index === currentImage ? 1 : 0 }}
            transition={{ duration: 0.5 }}
          >
            <img src={image.src || "/placeholder.svg"} alt={image.alt} className="w-full h-auto object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
            <div className="absolute bottom-0 left-0 right-0 p-6 text-center">
              <p className="text-lg font-medium mb-2">{image.title}</p>
              <p className="text-zinc-400">{image.description}</p>
            </div>
          </motion.div>
        ))}

        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {images.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full ${index === currentImage ? "bg-amber-500" : "bg-zinc-600"}`}
              onClick={() => setCurrentImage(index)}
            />
          ))}
        </div>
      </div>
    </Card>
  )
}
