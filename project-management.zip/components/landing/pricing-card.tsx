import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface PricingCardProps {
  title: string
  price: string
  description: string
  features: string[]
  buttonText: string
  buttonVariant: "default" | "outline"
  highlighted?: boolean
}

export function PricingCard({
  title,
  price,
  description,
  features,
  buttonText,
  buttonVariant,
  highlighted = false,
}: PricingCardProps) {
  return (
    <Card
      className={cn(
        "border-zinc-800 bg-zinc-900/30 backdrop-blur-sm transition-all duration-300",
        highlighted
          ? "border-amber-500/50 shadow-[0_0_15px_rgba(251,191,36,0.2)] scale-105 z-10"
          : "hover:border-amber-800/50 hover:shadow-[0_0_15px_rgba(251,191,36,0.1)]",
      )}
    >
      <CardHeader className="pb-2">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-1">{title}</h3>
          <div className="flex justify-center items-end mb-2">
            <span className="text-4xl font-bold">{price}</span>
            <span className="text-zinc-400 ml-1">/month</span>
          </div>
          <p className="text-sm text-zinc-400">{description}</p>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <ul className="space-y-3">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center">
              <Check className="h-5 w-5 text-amber-400 mr-2 flex-shrink-0" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Link href="/dashboard" className="w-full">
          <Button
            variant={buttonVariant}
            className={cn(
              "w-full",
              buttonVariant === "default"
                ? "bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
                : "border-zinc-700 hover:border-amber-500",
            )}
          >
            {buttonText}
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
