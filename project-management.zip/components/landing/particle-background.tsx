"use client"

import { useEffect, useRef } from "react"

export function ParticleBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setCanvasDimensions = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    setCanvasDimensions()
    window.addEventListener("resize", setCanvasDimensions)

    // Particle class
    class Particle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string
      originalX: number
      originalY: number
      density: number

      constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height
        this.originalX = this.x
        this.originalY = this.y
        this.size = Math.random() * 3 + 0.5
        this.speedX = Math.random() * 0.5 - 0.25
        this.speedY = Math.random() * 0.5 - 0.25
        this.color = `rgba(255, 215, 0, ${Math.random() * 0.2})`
        this.density = Math.random() * 30 + 1
      }

      update(mouseX?: number, mouseY?: number) {
        // Normal movement
        this.x += this.speedX
        this.y += this.speedY

        // Mouse interaction
        if (mouseX !== undefined && mouseY !== undefined) {
          const dx = mouseX - this.x
          const dy = mouseY - this.y
          const distance = Math.sqrt(dx * dx + dy * dy)
          const forceDirectionX = dx / distance
          const forceDirectionY = dy / distance
          const maxDistance = 100
          const force = (maxDistance - distance) / maxDistance

          if (distance < maxDistance) {
            this.x -= forceDirectionX * force * this.density
            this.y -= forceDirectionY * force * this.density
          } else {
            if (this.x !== this.originalX) {
              const dx = this.x - this.originalX
              this.x -= dx / 20
            }
            if (this.y !== this.originalY) {
              const dy = this.y - this.originalY
              this.y -= dy / 20
            }
          }
        }

        // Boundary check
        if (this.x > canvas.width) this.x = 0
        else if (this.x < 0) this.x = canvas.width

        if (this.y > canvas.height) this.y = 0
        else if (this.y < 0) this.y = canvas.height
      }

      draw() {
        if (!ctx) return
        ctx.fillStyle = this.color
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    // Create particles
    const particleCount = Math.min(100, Math.floor((window.innerWidth * window.innerHeight) / 10000))
    const particles: Particle[] = []

    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle())
    }

    // Mouse position
    let mouseX: number | undefined
    let mouseY: number | undefined

    window.addEventListener("mousemove", (e) => {
      mouseX = e.x
      mouseY = e.y
    })

    window.addEventListener("mouseout", () => {
      mouseX = undefined
      mouseY = undefined
    })

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle) => {
        particle.update(mouseX, mouseY)
        particle.draw()
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", setCanvasDimensions)
      window.removeEventListener("mousemove", (e) => {
        mouseX = e.x
        mouseY = e.y
      })
      window.removeEventListener("mouseout", () => {
        mouseX = undefined
        mouseY = undefined
      })
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 pointer-events-none" />
}
