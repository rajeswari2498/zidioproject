"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Project } from "@/types/project"
import { useTasks } from "@/hooks/use-tasks"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Calendar, BarChart } from "lucide-react"
import { TaskList } from "@/components/tasks/task-list"
import { BurndownChart } from "@/components/analytics/burndown-chart"
import { Progress } from "@/components/ui/progress"

interface Sprint {
  id: string
  name: string
  startDate: string
  endDate: string
  status: "active" | "completed" | "planned"
  progress: number
}

interface ProjectSprintProps {
  project: Project
}

export function ProjectSprint({ project }: ProjectSprintProps) {
  const { tasks } = useTasks()
  const [sprints, setSprints] = useState<Sprint[]>([
    {
      id: "sprint1",
      name: "Sprint 1",
      startDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(), // 14 days ago
      endDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
      status: "completed",
      progress: 100,
    },
    {
      id: "sprint2",
      name: "Sprint 2",
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 13).toISOString(), // 13 days from now
      status: "active",
      progress: 35,
    },
    {
      id: "sprint3",
      name: "Sprint 3",
      startDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14).toISOString(), // 14 days from now
      endDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 27).toISOString(), // 27 days from now
      status: "planned",
      progress: 0,
    },
  ])

  const [selectedSprint, setSelectedSprint] = useState<string>(sprints[1].id) // Default to active sprint

  // Get tasks for this project
  const projectTasks = tasks.filter((task) => task.projectId === project.id)

  // Get the selected sprint
  const sprint = sprints.find((s) => s.id === selectedSprint)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Sprint Planning</h2>
        <Button className="bg-amber-500 hover:bg-amber-600 text-black">
          <Plus className="h-4 w-4 mr-2" /> Create Sprint
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {sprints.map((sprint) => (
          <Card
            key={sprint.id}
            className={`border-zinc-800 bg-zinc-900/50 cursor-pointer hover:border-amber-800/50 transition-all duration-300 ${
              selectedSprint === sprint.id ? "border-amber-500" : ""
            }`}
            onClick={() => setSelectedSprint(sprint.id)}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{sprint.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <div className="text-zinc-400">
                    {new Date(sprint.startDate).toLocaleDateString()} - {new Date(sprint.endDate).toLocaleDateString()}
                  </div>
                  <div>
                    <span
                      className={
                        sprint.status === "active"
                          ? "text-green-400"
                          : sprint.status === "completed"
                            ? "text-blue-400"
                            : "text-amber-400"
                      }
                    >
                      {sprint.status.charAt(0).toUpperCase() + sprint.status.slice(1)}
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Progress</span>
                    <span>{sprint.progress}%</span>
                  </div>
                  <Progress value={sprint.progress} className="h-1.5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {sprint && (
        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader>
            <CardTitle>{sprint.name} Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="tasks">
              <TabsList className="bg-zinc-800 border-zinc-700 p-1">
                <TabsTrigger value="tasks">
                  <Calendar className="h-4 w-4 mr-2" /> Tasks
                </TabsTrigger>
                <TabsTrigger value="burndown">
                  <BarChart className="h-4 w-4 mr-2" /> Burndown Chart
                </TabsTrigger>
              </TabsList>
              <TabsContent value="tasks" className="mt-6">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="font-medium">Sprint Tasks</h3>
                    <p className="text-sm text-zinc-400">Manage tasks for this sprint</p>
                  </div>
                  <Button className="bg-amber-500 hover:bg-amber-600 text-black">
                    <Plus className="h-4 w-4 mr-2" /> Add Task
                  </Button>
                </div>
                <TaskList tasks={projectTasks.slice(0, 5)} />
              </TabsContent>
              <TabsContent value="burndown" className="mt-6">
                <div className="h-[400px]">
                  <BurndownChart sprintId={sprint.id} />
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
