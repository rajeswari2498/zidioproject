"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { Project } from "@/types/project"
import { useAuth } from "@/components/auth-provider"
import { PaperclipIcon, SendIcon, SmileIcon } from "lucide-react"

interface Message {
  id: string
  content: string
  sender: {
    id: string
    name: string
    avatar: string
  }
  timestamp: Date
}

interface ProjectChatProps {
  project: Project
}

export function ProjectChat({ project }: ProjectChatProps) {
  const { user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // In a real app, this would fetch messages from an API
    const mockMessages: Message[] = [
      {
        id: "1",
        content: "Hey team, I've started working on the homepage design.",
        sender: {
          id: "user1",
          name: "Sarah Smith",
          avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
        },
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      },
      {
        id: "2",
        content: "Looks great! Can you share the Figma link?",
        sender: {
          id: "user2",
          name: "John Doe",
          avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
        },
        timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      },
      {
        id: "3",
        content: "Sure, here it is: https://figma.com/file/example",
        sender: {
          id: "user1",
          name: "Sarah Smith",
          avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
        },
        timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      },
      {
        id: "4",
        content: "I've added some comments on the navigation section. Let's discuss in our next meeting.",
        sender: {
          id: "user3",
          name: "Mike Johnson",
          avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
        },
        timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
      },
    ]

    setMessages(mockMessages)
  }, [])

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim() || !user) return

    const newMsg: Message = {
      id: Date.now().toString(),
      content: newMessage,
      sender: {
        id: user.email,
        name: user.name,
        avatar: user.avatar,
      },
      timestamp: new Date(),
    }

    setMessages([...messages, newMsg])
    setNewMessage("")
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="flex flex-col h-[600px] border border-zinc-800 rounded-md overflow-hidden">
      <div className="p-4 border-b border-zinc-800 bg-zinc-900/50">
        <h3 className="font-bold">{project.name} - Team Chat</h3>
        <p className="text-xs text-zinc-400">{project.team.length} team members</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex gap-3 ${message.sender.id === user?.email ? "justify-end" : ""}`}>
            {message.sender.id !== user?.email && (
              <Avatar className="h-8 w-8">
                <AvatarImage src={message.sender.avatar || "/placeholder.svg"} alt={message.sender.name} />
                <AvatarFallback>{message.sender.name.charAt(0)}</AvatarFallback>
              </Avatar>
            )}

            <div
              className={`max-w-[70%] ${
                message.sender.id === user?.email ? "bg-amber-500/20" : "bg-zinc-800"
              } p-3 rounded-md`}
            >
              {message.sender.id !== user?.email && (
                <div className="font-medium text-sm mb-1">{message.sender.name}</div>
              )}
              <p className="text-sm">{message.content}</p>
              <div className="text-xs text-zinc-400 mt-1 text-right">{formatTime(message.timestamp)}</div>
            </div>

            {message.sender.id === user?.email && (
              <Avatar className="h-8 w-8">
                <AvatarImage src={message.sender.avatar || "/placeholder.svg"} alt={message.sender.name} />
                <AvatarFallback>{message.sender.name.charAt(0)}</AvatarFallback>
              </Avatar>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSendMessage} className="p-4 border-t border-zinc-800 bg-zinc-900/50">
        <div className="flex gap-2">
          <Button type="button" variant="outline" size="icon" className="h-10 w-10 border-zinc-700">
            <PaperclipIcon className="h-5 w-5" />
          </Button>
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="bg-zinc-800 border-zinc-700"
          />
          <Button type="button" variant="outline" size="icon" className="h-10 w-10 border-zinc-700">
            <SmileIcon className="h-5 w-5" />
          </Button>
          <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-black">
            <SendIcon className="h-5 w-5" />
          </Button>
        </div>
      </form>
    </div>
  )
}
