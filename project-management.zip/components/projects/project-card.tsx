import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Clock, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import type { Project } from "@/types/project"

interface ProjectCardProps {
  project: Project
}

export function ProjectCard({ project }: ProjectCardProps) {
  return (
    <Card className="border-zinc-800 bg-zinc-900/50 hover:border-amber-800/50 transition-all duration-300 hover:shadow-[0_0_15px_rgba(251,191,36,0.1)]">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <Link href={`/dashboard/projects/${project.id}`} className="hover:underline">
              <h3 className="font-bold text-lg">{project.name}</h3>
            </Link>
            <p className="text-zinc-400 text-sm mt-1">{project.description}</p>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Badge
              variant={
                project.status === "active" ? "default" : project.status === "completed" ? "outline" : "secondary"
              }
              className={
                project.status === "active"
                  ? "bg-green-500 text-black"
                  : project.status === "completed"
                    ? "border-green-500 text-green-500"
                    : "bg-amber-500 text-black"
              }
            >
              {project.status}
            </Badge>
            <div className="flex items-center text-xs text-zinc-400">
              <Clock className="h-3 w-3 mr-1" />
              Due {new Date(project.dueDate).toLocaleDateString()}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span>Progress</span>
              <span>{project.progress}%</span>
            </div>
            <Progress value={project.progress} className="h-1.5" />
          </div>

          <div className="flex justify-between items-center">
            <div className="flex -space-x-2">
              {project.team.slice(0, 4).map((member, index) => (
                <Avatar key={index} className="h-7 w-7 border-2 border-zinc-900">
                  <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                  <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                </Avatar>
              ))}
              {project.team.length > 4 && (
                <div className="h-7 w-7 rounded-full bg-zinc-800 border-2 border-zinc-900 flex items-center justify-center text-xs">
                  +{project.team.length - 4}
                </div>
              )}
            </div>
            <div className="text-xs text-zinc-400">{project.tasks.length} tasks</div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/dashboard/projects/${project.id}`} className="w-full">
          <Button variant="outline" className="w-full border-zinc-700">
            View Project
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
