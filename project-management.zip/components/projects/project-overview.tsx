"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectKanban } from "@/components/projects/project-kanban"
import { ProjectChat } from "@/components/projects/project-chat"
import { ProjectSprint } from "@/components/projects/project-sprint"
import { ProjectAnalytics } from "@/components/projects/project-analytics"
import { ProjectSettings } from "@/components/projects/project-settings"
import { useProjects } from "@/hooks/use-projects"
import { useMeetings } from "@/hooks/use-meetings"
import type { Project } from "@/types/project"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Calendar, MessageSquare, Video } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

interface ProjectOverviewProps {
  projectId: string
}

export function ProjectOverview({ projectId }: ProjectOverviewProps) {
  const { projects } = useProjects()
  const { meetings, getProjectMeetings } = useMeetings()
  const [project, setProject] = useState<Project | null>(null)
  const [projectMeetings, setProjectMeetings] = useState<any[]>([])

  useEffect(() => {
    const foundProject = projects.find((p) => p.id === projectId)
    if (foundProject) {
      setProject(foundProject)
    }

    // Get meetings for this project
    const meetings = getProjectMeetings(projectId)
    setProjectMeetings(meetings)
  }, [projectId, projects, meetings, getProjectMeetings])

  if (!project) {
    return <div>Project not found</div>
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "not_started":
        return "bg-zinc-500"
      case "in_progress":
        return "bg-blue-500"
      case "on_hold":
        return "bg-amber-500"
      case "completed":
        return "bg-green-500"
      default:
        return "bg-zinc-500"
    }
  }

  return (
    <div className="space-y-6">
      <Card className="border-zinc-800 bg-zinc-900/50">
        <CardHeader className="flex flex-row items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <CardTitle>{project.name}</CardTitle>
              <Badge className={cn("ml-2", getStatusColor(project.status))}>
                {project.status === "not_started" && "Not Started"}
                {project.status === "in_progress" && "In Progress"}
                {project.status === "on_hold" && "On Hold"}
                {project.status === "completed" && "Completed"}
              </Badge>
            </div>
            <CardDescription>{project.description}</CardDescription>
            <div className="flex items-center gap-4 mt-2 text-sm">
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4 text-zinc-400" />
                <span>
                  {format(new Date(project.startDate), "MMM d, yyyy")} -{" "}
                  {format(new Date(project.endDate), "MMM d, yyyy")}
                </span>
              </div>
            </div>
          </div>
          <div className="flex -space-x-2">
            {project.team.map((member, index) => (
              <Avatar key={index} className="border-2 border-zinc-900 h-8 w-8">
                <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
              </Avatar>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {projectMeetings.length > 0 && (
            <div className="mb-6">
              <h3 className="text-sm font-medium mb-2">Upcoming Meetings</h3>
              <div className="space-y-2">
                {projectMeetings.map((meeting) => (
                  <div
                    key={meeting.id}
                    className="flex items-center justify-between p-3 bg-zinc-800 rounded-md border border-zinc-700"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "h-10 w-10 rounded-full flex items-center justify-center",
                          meeting.type === "video" ? "bg-blue-500/20" : "bg-amber-500/20",
                        )}
                      >
                        {meeting.type === "video" ? (
                          <Video className="h-5 w-5 text-blue-500" />
                        ) : (
                          <MessageSquare className="h-5 w-5 text-amber-500" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{meeting.title}</p>
                        <p className="text-xs text-zinc-400">
                          {format(new Date(meeting.startTime), "MMM d, h:mm a")} -{" "}
                          {format(new Date(meeting.endTime), "h:mm a")}
                        </p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="border-zinc-700">
                      Join
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Tabs defaultValue="kanban">
            <TabsList className="bg-zinc-800 border-zinc-700">
              <TabsTrigger value="kanban">Kanban Board</TabsTrigger>
              <TabsTrigger value="sprint">Sprints</TabsTrigger>
              <TabsTrigger value="chat">Team Chat</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            <TabsContent value="kanban" className="mt-4">
              <ProjectKanban projectId={projectId} />
            </TabsContent>
            <TabsContent value="sprint" className="mt-4">
              <ProjectSprint projectId={projectId} />
            </TabsContent>
            <TabsContent value="chat" className="mt-4">
              <ProjectChat projectId={projectId} />
            </TabsContent>
            <TabsContent value="analytics" className="mt-4">
              <ProjectAnalytics projectId={projectId} />
            </TabsContent>
            <TabsContent value="settings" className="mt-4">
              <ProjectSettings project={project} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
