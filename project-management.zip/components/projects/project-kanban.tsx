"use client"

import { useState } from "react"
import { DndProvider, useDrop } from "react-dnd"
import { HTML5Backend } from "react-dnd-html5-backend"
import { Button } from "@/components/ui/button"
import { Plus, MoreHorizontal } from "lucide-react"
import type { Project } from "@/types/project"
import type { Task } from "@/types/task"
import { useTasks } from "@/hooks/use-tasks"
import { KanbanCard } from "@/components/projects/kanban-card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"

interface KanbanColumnProps {
  title: string
  tasks: Task[]
  status: string
  onDrop: (item: Task, status: string) => void
  onAddTask: (status: string) => void
}

function KanbanColumn({ title, tasks, status, onDrop, onAddTask }: KanbanColumnProps) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: "task",
    drop: (item: Task) => onDrop(item, status),
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }))

  return (
    <div
      ref={drop}
      className={`kanban-column bg-zinc-900/30 rounded-md p-4 border ${
        isOver ? "border-amber-500" : "border-zinc-800"
      }`}
    >
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium">{title}</h3>
        <div className="flex items-center gap-1">
          <span className="text-xs text-zinc-400 bg-zinc-800 px-2 py-1 rounded-md">{tasks.length}</span>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-zinc-400 hover:text-white"
            onClick={() => onAddTask(status)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="space-y-3">
        {tasks.map((task) => (
          <KanbanCard key={task.id} task={task} />
        ))}
        {tasks.length === 0 && (
          <div className="text-center py-8 text-zinc-500 text-sm border border-dashed border-zinc-800 rounded-md">
            No tasks
          </div>
        )}
      </div>
    </div>
  )
}

interface ProjectKanbanProps {
  project: Project
}

export function ProjectKanban({ project }: ProjectKanbanProps) {
  const { tasks, updateTask } = useTasks()
  const [columns, setColumns] = useState<string[]>(["To Do", "In Progress", "Review", "Done"])
  const [newColumnName, setNewColumnName] = useState("")
  const [showNewColumnInput, setShowNewColumnInput] = useState(false)

  // Get tasks for this project
  const projectTasks = tasks.filter((task) => task.projectId === project.id)

  const handleDrop = (task: Task, newStatus: string) => {
    updateTask(task.id, { ...task, status: newStatus })
  }

  const handleAddTask = (status: string) => {
    // In a real app, this would open a dialog to create a new task
    console.log(`Add task to ${status}`)
  }

  const addNewColumn = () => {
    if (newColumnName.trim()) {
      setColumns([...columns, newColumnName.trim()])
      setNewColumnName("")
      setShowNewColumnInput(false)
    }
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Kanban Board</h2>
          <div className="flex gap-2">
            <Button variant="outline" className="border-zinc-700" onClick={() => setShowNewColumnInput(true)}>
              <Plus className="h-4 w-4 mr-2" /> Add Column
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="h-9 w-9 border-zinc-700">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Save Layout</DropdownMenuItem>
                <DropdownMenuItem>Reset Layout</DropdownMenuItem>
                <DropdownMenuItem>Filter Tasks</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {showNewColumnInput && (
          <div className="flex gap-2">
            <Input
              placeholder="Column name"
              value={newColumnName}
              onChange={(e) => setNewColumnName(e.target.value)}
              className="bg-zinc-800 border-zinc-700"
              autoFocus
            />
            <Button onClick={addNewColumn}>Add</Button>
            <Button variant="outline" onClick={() => setShowNewColumnInput(false)}>
              Cancel
            </Button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((column) => (
            <KanbanColumn
              key={column}
              title={column}
              status={column}
              tasks={projectTasks.filter((task) => task.status === column)}
              onDrop={handleDrop}
              onAddTask={handleAddTask}
            />
          ))}
        </div>
      </div>
    </DndProvider>
  )
}
