"use client"

import { useDrag } from "react-dnd"
import type { Task } from "@/types/task"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card } from "@/components/ui/card"

interface KanbanCardProps {
  task: Task
}

export function KanbanCard({ task }: KanbanCardProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "task",
    item: task,
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }))

  return (
    <Card
      ref={drag}
      className={`task-card p-3 cursor-grab border-zinc-800 bg-zinc-800/50 ${
        isDragging ? "opacity-50" : "opacity-100"
      }`}
    >
      <div className="space-y-2">
        <div className="flex justify-between items-start">
          <Badge
            variant="outline"
            className={
              task.type === "Bug"
                ? "border-red-500 text-red-500"
                : task.type === "Feature"
                  ? "border-blue-500 text-blue-500"
                  : task.type === "Epic"
                    ? "border-purple-500 text-purple-500"
                    : "border-zinc-500 text-zinc-500"
            }
          >
            {task.type}
          </Badge>
          <Badge
            variant={task.priority === "High" ? "default" : task.priority === "Medium" ? "outline" : "secondary"}
            className={
              task.priority === "High"
                ? "bg-red-500 text-white"
                : task.priority === "Medium"
                  ? "border-amber-500 text-amber-500"
                  : "bg-blue-500 text-white"
            }
          >
            {task.priority}
          </Badge>
        </div>

        <h4 className="font-medium">{task.title}</h4>

        {task.description && <p className="text-xs text-zinc-400 line-clamp-2">{task.description}</p>}

        <div className="flex justify-between items-center pt-1">
          <Avatar className="h-6 w-6">
            <AvatarImage src={task.assignee.avatar || "/placeholder.svg"} alt={task.assignee.name} />
            <AvatarFallback>{task.assignee.name.charAt(0)}</AvatarFallback>
          </Avatar>

          <div className="text-xs text-zinc-400">{new Date(task.dueDate).toLocaleDateString()}</div>
        </div>
      </div>
    </Card>
  )
}
