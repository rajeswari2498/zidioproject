"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Project } from "@/types/project"
import { ProjectCompletionChart } from "@/components/analytics/project-completion-chart"
import { TaskDistributionChart } from "@/components/analytics/task-distribution-chart"
import { TeamPerformanceChart } from "@/components/analytics/team-performance-chart"

interface ProjectAnalyticsProps {
  project: Project
}

export function ProjectAnalytics({ project }: ProjectAnalyticsProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader>
            <CardTitle>Task Status Distribution</CardTitle>
            <CardDescription>Current distribution of tasks by status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <TaskDistributionChart projectId={project.id} />
            </div>
          </CardContent>
        </Card>

        <Card className="border-zinc-800 bg-zinc-900/50">
          <CardHeader>
            <CardTitle>Task Type Distribution</CardTitle>
            <CardDescription>Distribution of tasks by type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <TaskDistributionChart type="type" projectId={project.id} />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-zinc-800 bg-zinc-900/50">
        <CardHeader>
          <CardTitle>Project Completion</CardTitle>
          <CardDescription>Project completion rate over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ProjectCompletionChart projectId={project.id} />
          </div>
        </CardContent>
      </Card>

      <Card className="border-zinc-800 bg-zinc-900/50">
        <CardHeader>
          <CardTitle>Team Performance</CardTitle>
          <CardDescription>Task completion by team member</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <TeamPerformanceChart projectId={project.id} />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
