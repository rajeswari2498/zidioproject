"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

type User = {
  email: string
  name: string
  role: "admin" | "project_manager" | "team_member"
  avatar: string
}

type AuthContextType = {
  user: User | null
  login: (email: string, name?: string, role?: User["role"]) => void
  logout: () => void
  setUserRole: (role: User["role"]) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
  }, [])

  const login = (email: string, name?: string, role?: User["role"]) => {
    // In a real app, this would validate credentials with a backend
    // For demo purposes, we'll create a user based on the email
    const newUser: User = {
      email,
      name: name || email.split("@")[0],
      role: role || "admin", // Default role
      avatar: `https://ui-avatars.com/api/?name=${name || email.split("@")[0]}&background=random`,
    }

    setUser(newUser)
    localStorage.setItem("user", JSON.stringify(newUser))
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  const setUserRole = (role: User["role"]) => {
    if (user) {
      const updatedUser = { ...user, role }
      setUser(updatedUser)
      localStorage.setItem("user", JSON.stringify(updatedUser))
    }
  }

  return <AuthContext.Provider value={{ user, login, logout, setUserRole }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
