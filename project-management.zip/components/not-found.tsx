import { Button } from "@/components/ui/button"
import { FileQuestion } from "lucide-react"
import Link from "next/link"

interface NotFoundProps {
  type: "project" | "task" | "page"
}

export function NotFound({ type }: NotFoundProps) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <FileQuestion className="h-16 w-16 text-zinc-500 mb-4" />
      <h1 className="text-2xl font-bold mb-2">Not Found</h1>
      <p className="text-zinc-400 mb-6">
        {type === "project"
          ? "The project you're looking for doesn't exist or has been deleted."
          : type === "task"
            ? "The task you're looking for doesn't exist or has been deleted."
            : "The page you're looking for doesn't exist."}
      </p>
      <Link href={type === "project" || type === "task" ? "/dashboard" : "/"}>
        <Button className="bg-amber-500 hover:bg-amber-600 text-black">
          {type === "project" ? "Go to Projects" : type === "task" ? "Go to Tasks" : "Go to Dashboard"}
        </Button>
      </Link>
    </div>
  )
}
