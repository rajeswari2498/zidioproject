"use client"

import React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Clock, Loader2, Video } from "lucide-react"
import { format, setHours, setMinutes } from "date-fns"
import { cn } from "@/lib/utils"
import { toast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useProjects } from "@/hooks/use-projects"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"
import { useMeetings } from "@/hooks/use-meetings"

interface ScheduleMeetingDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ScheduleMeetingDialog({ open, onOpenChange }: ScheduleMeetingDialogProps) {
  const { projects } = useProjects()
  const { addMeeting } = useMeetings()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState<Date>(new Date())
  const [startTime, setStartTime] = useState("09:00")
  const [duration, setDuration] = useState("60")
  const [selectedProject, setSelectedProject] = useState("none")
  const [meetingType, setMeetingType] = useState("video")
  const [isLoading, setIsLoading] = useState(false)
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([])

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      setTitle("")
      setDescription("")
      setDate(new Date())
      setStartTime("09:00")
      setDuration("60")
      setSelectedProject("none")
      setMeetingType("video")
      setSelectedParticipants([])
    }
  }, [open])

  // Mock team members
  const teamMembers = [
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      role: "Frontend Developer",
      avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
    },
    {
      id: "2",
      name: "Sarah Smith",
      email: "sarah@example.com",
      role: "UI/UX Designer",
      avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
    },
    {
      id: "3",
      name: "Mike Johnson",
      email: "mike@example.com",
      role: "Backend Developer",
      avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
    },
    {
      id: "4",
      name: "Emily Chen",
      email: "emily@example.com",
      role: "Project Manager",
      avatar: "https://ui-avatars.com/api/?name=Emily+Chen&background=random",
    },
    {
      id: "5",
      name: "David Wilson",
      email: "david@example.com",
      role: "QA Engineer",
      avatar: "https://ui-avatars.com/api/?name=David+Wilson&background=random",
    },
  ]

  const toggleParticipant = (id: string) => {
    setSelectedParticipants((prev) => (prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    if (!title || !date) return

    // Calculate meeting end time
    const startDate = new Date(date)
    const [hours, minutes] = startTime.split(":").map(Number)
    startDate.setHours(hours, minutes)

    const endDate = new Date(startDate)
    endDate.setMinutes(endDate.getMinutes() + Number.parseInt(duration))

    // Create meeting object
    const newMeeting = {
      id: `meeting-${Date.now()}`,
      title,
      description,
      startTime: startDate.toISOString(),
      endTime: endDate.toISOString(),
      projectId: selectedProject !== "none" ? selectedProject : null,
      type: meetingType,
      participants: teamMembers.filter((member) => selectedParticipants.includes(member.id)),
      link: `https://meet.example.com/${Math.random().toString(36).substring(2, 10)}`,
      createdAt: new Date().toISOString(),
    }

    // Add meeting to store
    setTimeout(() => {
      addMeeting(newMeeting)

      toast({
        title: "Meeting scheduled",
        description: `${title} scheduled for ${format(startDate, "PPP")} at ${format(startDate, "h:mm a")}`,
      })

      setIsLoading(false)
      onOpenChange(false)
    }, 1000)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] bg-zinc-900 border-zinc-800">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Schedule Meeting</DialogTitle>
            <DialogDescription>Schedule a meeting with your team using WebRTC video conferencing</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="details" className="mt-4">
            <TabsList className="bg-zinc-800 border-zinc-700 p-1">
              <TabsTrigger value="details">Meeting Details</TabsTrigger>
              <TabsTrigger value="participants">Participants</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="title">Meeting Title</Label>
                <Input
                  id="title"
                  placeholder="Enter meeting title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="bg-zinc-800 border-zinc-700"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Enter meeting description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="bg-zinc-800 border-zinc-700 min-h-[100px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal bg-zinc-800 border-zinc-700",
                          !date && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-zinc-900 border-zinc-800">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(date) => date && setDate(date)}
                        initialFocus
                        disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="startTime">Start Time</Label>
                  <Select value={startTime} onValueChange={setStartTime}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 24 }).map((_, hour) => (
                        <React.Fragment key={hour}>
                          <SelectItem value={`${hour.toString().padStart(2, "0")}:00`}>
                            {format(setHours(new Date(), hour), "h:mm a")}
                          </SelectItem>
                          <SelectItem value={`${hour.toString().padStart(2, "0")}:30`}>
                            {format(setHours(setMinutes(new Date(), 30), hour), "h:mm a")}
                          </SelectItem>
                        </React.Fragment>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration</Label>
                  <Select value={duration} onValueChange={setDuration}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="45">45 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="90">1.5 hours</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="project">Related Project (Optional)</Label>
                  <Select value={selectedProject} onValueChange={setSelectedProject}>
                    <SelectTrigger className="bg-zinc-800 border-zinc-700">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="meetingType">Meeting Type</Label>
                <div className="flex gap-4 mt-2">
                  <div
                    className={cn(
                      "flex flex-col items-center gap-2 p-3 rounded-md cursor-pointer border",
                      meetingType === "video"
                        ? "border-amber-500 bg-amber-500/10"
                        : "border-zinc-700 bg-zinc-800 hover:border-zinc-600",
                    )}
                    onClick={() => setMeetingType("video")}
                  >
                    <Video className={cn("h-6 w-6", meetingType === "video" ? "text-amber-500" : "text-zinc-400")} />
                    <span className={meetingType === "video" ? "text-amber-500" : "text-zinc-400"}>Video Call</span>
                  </div>
                  <div
                    className={cn(
                      "flex flex-col items-center gap-2 p-3 rounded-md cursor-pointer border",
                      meetingType === "audio"
                        ? "border-amber-500 bg-amber-500/10"
                        : "border-zinc-700 bg-zinc-800 hover:border-zinc-600",
                    )}
                    onClick={() => setMeetingType("audio")}
                  >
                    <Clock className={cn("h-6 w-6", meetingType === "audio" ? "text-amber-500" : "text-zinc-400")} />
                    <span className={meetingType === "audio" ? "text-amber-500" : "text-zinc-400"}>Audio Call</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="participants" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Select Participants</Label>
                <div className="bg-zinc-800 rounded-md border border-zinc-700 p-2 max-h-[300px] overflow-y-auto">
                  {teamMembers.map((member) => (
                    <div
                      key={member.id}
                      className={cn(
                        "flex items-center space-x-3 p-2 rounded-md cursor-pointer hover:bg-zinc-700",
                        selectedParticipants.includes(member.id) && "bg-amber-500/10 border border-amber-500/30",
                      )}
                      onClick={() => toggleParticipant(member.id)}
                    >
                      <Checkbox
                        checked={selectedParticipants.includes(member.id)}
                        onCheckedChange={() => toggleParticipant(member.id)}
                        className="data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
                      />
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{member.name}</p>
                        <p className="text-xs text-zinc-400">{member.role}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-sm text-zinc-400 mt-2">{selectedParticipants.length} participants selected</p>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-6">
            <Button
              type="submit"
              className="bg-gradient-to-r from-amber-400 to-yellow-600 hover:from-amber-500 hover:to-yellow-700 text-black"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Scheduling...
                </>
              ) : (
                <>
                  <Video className="mr-2 h-4 w-4" /> Schedule Meeting
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
