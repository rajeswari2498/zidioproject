"use client"

import { useState, useEffect, useCallback } from "react"
import type { Project } from "@/types/project"

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>([])

  useEffect(() => {
    // In a real app, this would fetch from an API
    const mockProjects: Project[] = [
      {
        id: "1",
        name: "Website Redesign",
        description: "Redesign the company website with a modern look and improved UX",
        status: "active",
        progress: 65,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(), // 30 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 15).toISOString(), // 15 days from now
        team: [
          {
            name: "John Doe",
            role: "Project Manager",
            avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
            tasks: 5,
          },
          {
            name: "Sarah Smith",
            role: "UI/UX Designer",
            avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
            tasks: 8,
          },
          {
            name: "Mike Johnson",
            role: "Frontend Developer",
            avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
            tasks: 6,
          },
          {
            name: "Emily Chen",
            role: "Backend Developer",
            avatar: "https://ui-avatars.com/api/?name=Emily+Chen&background=random",
            tasks: 4,
          },
        ],
        tasks: [
          {
            id: "task1",
            title: "Design homepage mockup",
            status: "Done",
          },
          {
            id: "task2",
            title: "Implement responsive navigation",
            status: "In Progress",
          },
          {
            id: "task3",
            title: "Create product showcase section",
            status: "To Do",
          },
          {
            id: "task4",
            title: "Optimize images and assets",
            status: "To Do",
          },
          {
            id: "task5",
            title: "Set up analytics",
            status: "To Do",
          },
        ],
      },
      {
        id: "2",
        name: "Mobile App Development",
        description: "Develop a cross-platform mobile app for customer engagement",
        status: "active",
        progress: 35,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15).toISOString(), // 15 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 45).toISOString(), // 45 days from now
        team: [
          {
            name: "David Wilson",
            role: "Project Manager",
            avatar: "https://ui-avatars.com/api/?name=David+Wilson&background=random",
            tasks: 3,
          },
          {
            name: "Jessica Lee",
            role: "UI/UX Designer",
            avatar: "https://ui-avatars.com/api/?name=Jessica+Lee&background=random",
            tasks: 5,
          },
          {
            name: "Alex Brown",
            role: "Mobile Developer",
            avatar: "https://ui-avatars.com/api/?name=Alex+Brown&background=random",
            tasks: 7,
          },
        ],
        tasks: [
          {
            id: "task6",
            title: "Design user interface",
            status: "Done",
          },
          {
            id: "task7",
            title: "Implement authentication",
            status: "In Progress",
          },
          {
            id: "task8",
            title: "Create product catalog",
            status: "To Do",
          },
          {
            id: "task9",
            title: "Implement push notifications",
            status: "To Do",
          },
        ],
      },
      {
        id: "3",
        name: "Marketing Campaign",
        description: "Launch a digital marketing campaign for the new product line",
        status: "on-hold",
        progress: 20,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), // 10 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 20).toISOString(), // 20 days from now
        team: [
          {
            name: "Lisa Wang",
            role: "Marketing Manager",
            avatar: "https://ui-avatars.com/api/?name=Lisa+Wang&background=random",
            tasks: 6,
          },
          {
            name: "Tom Harris",
            role: "Content Creator",
            avatar: "https://ui-avatars.com/api/?name=Tom+Harris&background=random",
            tasks: 4,
          },
          {
            name: "Rachel Green",
            role: "Social Media Specialist",
            avatar: "https://ui-avatars.com/api/?name=Rachel+Green&background=random",
            tasks: 5,
          },
        ],
        tasks: [
          {
            id: "task10",
            title: "Define target audience",
            status: "Done",
          },
          {
            id: "task11",
            title: "Create content calendar",
            status: "In Progress",
          },
          {
            id: "task12",
            title: "Design social media assets",
            status: "To Do",
          },
          {
            id: "task13",
            title: "Set up ad campaigns",
            status: "To Do",
          },
          {
            id: "task14",
            title: "Prepare analytics dashboard",
            status: "To Do",
          },
        ],
      },
      {
        id: "4",
        name: "Product Launch",
        description: "Coordinate the launch of our new flagship product",
        status: "active",
        progress: 80,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 60).toISOString(), // 60 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 5).toISOString(), // 5 days from now
        team: [
          {
            name: "Mark Johnson",
            role: "Product Manager",
            avatar: "https://ui-avatars.com/api/?name=Mark+Johnson&background=random",
            tasks: 7,
          },
          {
            name: "Anna Smith",
            role: "Marketing Specialist",
            avatar: "https://ui-avatars.com/api/?name=Anna+Smith&background=random",
            tasks: 5,
          },
          {
            name: "Chris Davis",
            role: "Sales Manager",
            avatar: "https://ui-avatars.com/api/?name=Chris+Davis&background=random",
            tasks: 4,
          },
          {
            name: "Linda Chen",
            role: "Customer Support",
            avatar: "https://ui-avatars.com/api/?name=Linda+Chen&background=random",
            tasks: 3,
          },
        ],
        tasks: [
          {
            id: "task15",
            title: "Finalize product features",
            status: "Done",
          },
          {
            id: "task16",
            title: "Prepare marketing materials",
            status: "Done",
          },
          {
            id: "task17",
            title: "Train sales team",
            status: "Done",
          },
          {
            id: "task18",
            title: "Prepare press release",
            status: "In Progress",
          },
          {
            id: "task19",
            title: "Organize launch event",
            status: "In Progress",
          },
          {
            id: "task20",
            title: "Set up customer support",
            status: "To Do",
          },
        ],
      },
      {
        id: "5",
        name: "Infrastructure Upgrade",
        description: "Upgrade our server infrastructure and migrate to the cloud",
        status: "completed",
        progress: 100,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 90).toISOString(), // 90 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), // 10 days ago
        dueDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), // 5 days ago
        team: [
          {
            name: "Robert Kim",
            role: "IT Manager",
            avatar: "https://ui-avatars.com/api/?name=Robert+Kim&background=random",
            tasks: 6,
          },
          {
            name: "Michelle Wong",
            role: "System Administrator",
            avatar: "https://ui-avatars.com/api/?name=Michelle+Wong&background=random",
            tasks: 8,
          },
          {
            name: "James Taylor",
            role: "DevOps Engineer",
            avatar: "https://ui-avatars.com/api/?name=James+Taylor&background=random",
            tasks: 7,
          },
        ],
        tasks: [
          {
            id: "task21",
            title: "Assess current infrastructure",
            status: "Done",
          },
          {
            id: "task22",
            title: "Design cloud architecture",
            status: "Done",
          },
          {
            id: "task23",
            title: "Set up new servers",
            status: "Done",
          },
          {
            id: "task24",
            title: "Migrate databases",
            status: "Done",
          },
          {
            id: "task25",
            title: "Test performance",
            status: "Done",
          },
          {
            id: "task26",
            title: "Switch to new infrastructure",
            status: "Done",
          },
        ],
      },
    ]

    setProjects(mockProjects)
  }, [])

  const getProjectById = useCallback(
    (id: string) => {
      return projects.find((project) => project.id === id)
    },
    [projects],
  )

  const addProject = useCallback((projectData: Partial<Project>) => {
    const newProject: Project = {
      id: Date.now().toString(),
      name: projectData.name || "New Project",
      description: projectData.description || "",
      status: projectData.status || "active",
      progress: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      dueDate: projectData.dueDate || new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(), // 30 days from now
      team: [],
      tasks: [],
    }

    setProjects((prev) => [...prev, newProject])
    return newProject
  }, [])

  const updateProject = useCallback((id: string, projectData: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id === id) {
          return {
            ...project,
            ...projectData,
            updatedAt: new Date().toISOString(),
          }
        }
        return project
      }),
    )
  }, [])

  const deleteProject = useCallback((id: string) => {
    setProjects((prev) => prev.filter((project) => project.id !== id))
  }, [])

  return {
    projects,
    getProjectById,
    addProject,
    updateProject,
    deleteProject,
  }
}
