"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

type Meeting = {
  id: string
  title: string
  description: string
  startTime: string
  endTime: string
  projectId: string | null
  type: "video" | "audio"
  participants: {
    id: string
    name: string
    email: string
    role: string
    avatar: string
  }[]
  link: string
  createdAt: string
}

type MeetingsContextType = {
  meetings: Meeting[]
  addMeeting: (meeting: Meeting) => void
  removeMeeting: (id: string) => void
  getProjectMeetings: (projectId: string) => Meeting[]
  getUpcomingMeetings: () => Meeting[]
}

const MeetingsContext = createContext<MeetingsContextType | undefined>(undefined)

export function MeetingsProvider({ children }: { children: React.ReactNode }) {
  const [meetings, setMeetings] = useState<Meeting[]>([])

  useEffect(() => {
    // Load meetings from localStorage
    const storedMeetings = localStorage.getItem("meetings")
    if (storedMeetings) {
      setMeetings(JSON.parse(storedMeetings))
    } else {
      // Initialize with mock meetings if none exist
      const initialMeetings: Meeting[] = [
        {
          id: "meeting-1",
          title: "Sprint Planning",
          description: "Plan tasks for the upcoming sprint",
          startTime: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
          endTime: new Date(Date.now() + 86400000 + 3600000).toISOString(), // Tomorrow + 1 hour
          projectId: "project-1",
          type: "video",
          participants: [
            {
              id: "1",
              name: "John Doe",
              email: "john@example.com",
              role: "Frontend Developer",
              avatar: "https://ui-avatars.com/api/?name=John+Doe&background=random",
            },
            {
              id: "2",
              name: "Sarah Smith",
              email: "sarah@example.com",
              role: "UI/UX Designer",
              avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
            },
          ],
          link: "https://meet.example.com/abc123",
          createdAt: new Date().toISOString(),
        },
        {
          id: "meeting-2",
          title: "Design Review",
          description: "Review the latest design mockups",
          startTime: new Date(Date.now() + 172800000).toISOString(), // Day after tomorrow
          endTime: new Date(Date.now() + 172800000 + 5400000).toISOString(), // Day after tomorrow + 1.5 hours
          projectId: "project-2",
          type: "video",
          participants: [
            {
              id: "2",
              name: "Sarah Smith",
              email: "sarah@example.com",
              role: "UI/UX Designer",
              avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
            },
            {
              id: "4",
              name: "Emily Chen",
              email: "emily@example.com",
              role: "Project Manager",
              avatar: "https://ui-avatars.com/api/?name=Emily+Chen&background=random",
            },
          ],
          link: "https://meet.example.com/def456",
          createdAt: new Date().toISOString(),
        },
      ]
      setMeetings(initialMeetings)
      localStorage.setItem("meetings", JSON.stringify(initialMeetings))
    }
  }, [])

  const addMeeting = (meeting: Meeting) => {
    const updatedMeetings = [...meetings, meeting]
    setMeetings(updatedMeetings)
    localStorage.setItem("meetings", JSON.stringify(updatedMeetings))
  }

  const removeMeeting = (id: string) => {
    const updatedMeetings = meetings.filter((meeting) => meeting.id !== id)
    setMeetings(updatedMeetings)
    localStorage.setItem("meetings", JSON.stringify(updatedMeetings))
  }

  const getProjectMeetings = (projectId: string) => {
    return meetings.filter((meeting) => meeting.projectId === projectId)
  }

  const getUpcomingMeetings = () => {
    const now = new Date()
    return meetings
      .filter((meeting) => new Date(meeting.startTime) > now)
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())
  }

  return (
    <MeetingsContext.Provider
      value={{
        meetings,
        addMeeting,
        removeMeeting,
        getProjectMeetings,
        getUpcomingMeetings,
      }}
    >
      {children}
    </MeetingsContext.Provider>
  )
}

export function useMeetings() {
  const context = useContext(MeetingsContext)
  if (context === undefined) {
    throw new Error("useMeetings must be used within a MeetingsProvider")
  }
  return context
}
