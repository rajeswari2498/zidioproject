"use client"

import { useState, useEffect, useCallback } from "react"
import type { Task } from "@/types/task"
import { useAuth } from "@/components/auth-provider"

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>([])
  const { user } = useAuth()

  useEffect(() => {
    // In a real app, this would fetch from an API
    const mockTasks: Task[] = [
      {
        id: "1",
        title: "Design homepage mockup",
        description: "Create a modern and responsive design for the homepage",
        type: "Feature",
        priority: "High",
        status: "Done",
        projectId: "1",
        projectName: "Website Redesign",
        assignee: {
          id: "user1",
          name: "Sarah Smith",
          role: "UI/UX Designer",
          avatar: "https://ui-avatars.com/api/?name=Sarah+Smith&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), // 10 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days ago
        dueDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
      },
      {
        id: "2",
        title: "Implement responsive navigation",
        description: "Create a responsive navigation menu that works on all devices",
        type: "Feature",
        priority: "Medium",
        status: "In Progress",
        projectId: "1",
        projectName: "Website Redesign",
        assignee: {
          id: "user2",
          name: "Mike Johnson",
          role: "Frontend Developer",
          avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8).toISOString(), // 8 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days from now
      },
      {
        id: "3",
        title: "Fix navigation bug on mobile",
        description: "The navigation menu doesn't close when clicking outside on mobile devices",
        type: "Bug",
        priority: "High",
        status: "To Do",
        projectId: "1",
        projectName: "Website Redesign",
        assignee: {
          id: "user2",
          name: "Mike Johnson",
          role: "Frontend Developer",
          avatar: "https://ui-avatars.com/api/?name=Mike+Johnson&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days from now
      },
      {
        id: "4",
        title: "Implement user authentication",
        description: "Set up user authentication with JWT and secure routes",
        type: "Feature",
        priority: "High",
        status: "In Progress",
        projectId: "2",
        projectName: "Mobile App Development",
        assignee: {
          id: "user3",
          name: "Alex Brown",
          role: "Mobile Developer",
          avatar: "https://ui-avatars.com/api/?name=Alex+Brown&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 5).toISOString(), // 5 days from now
      },
      {
        id: "5",
        title: "Design product catalog UI",
        description: "Create UI designs for the product catalog section of the app",
        type: "Feature",
        priority: "Medium",
        status: "Done",
        projectId: "2",
        projectName: "Mobile App Development",
        assignee: {
          id: "user4",
          name: "Jessica Lee",
          role: "UI/UX Designer",
          avatar: "https://ui-avatars.com/api/?name=Jessica+Lee&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), // 10 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
        dueDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
      },
      {
        id: "6",
        title: "Create content calendar",
        description: "Develop a content calendar for social media posts and blog articles",
        type: "Task",
        priority: "Medium",
        status: "In Progress",
        projectId: "3",
        projectName: "Marketing Campaign",
        assignee: {
          id: "user5",
          name: "Tom Harris",
          role: "Content Creator",
          avatar: "https://ui-avatars.com/api/?name=Tom+Harris&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), // 5 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 4).toISOString(), // 4 days from now
      },
      {
        id: "7",
        title: "Set up ad campaigns",
        description: "Configure and launch advertising campaigns on Google and Facebook",
        type: "Task",
        priority: "High",
        status: "To Do",
        projectId: "3",
        projectName: "Marketing Campaign",
        assignee: {
          id: "user6",
          name: "Lisa Wang",
          role: "Marketing Manager",
          avatar: "https://ui-avatars.com/api/?name=Lisa+Wang&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days from now
      },
      {
        id: "8",
        title: "Prepare press release",
        description: "Write and distribute press release for the product launch",
        type: "Task",
        priority: "Medium",
        status: "In Progress",
        projectId: "4",
        projectName: "Product Launch",
        assignee: {
          id: "user7",
          name: "Anna Smith",
          role: "Marketing Specialist",
          avatar: "https://ui-avatars.com/api/?name=Anna+Smith&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
        dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days from now
      },
      {
        id: "9",
        title: "Train sales team",
        description: "Conduct training sessions for the sales team on the new product",
        type: "Task",
        priority: "High",
        status: "Done",
        projectId: "4",
        projectName: "Product Launch",
        assignee: {
          id: "user8",
          name: "Chris Davis",
          role: "Sales Manager",
          avatar: "https://ui-avatars.com/api/?name=Chris+Davis&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(), // 14 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
        dueDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), // 1 day ago
      },
      {
        id: "10",
        title: "Migrate databases",
        description: "Migrate data from old servers to the new cloud infrastructure",
        type: "Epic",
        priority: "High",
        status: "Done",
        projectId: "5",
        projectName: "Infrastructure Upgrade",
        assignee: {
          id: "user9",
          name: "Michelle Wong",
          role: "System Administrator",
          avatar: "https://ui-avatars.com/api/?name=Michelle+Wong&background=random",
        },
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(), // 30 days ago
        updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15).toISOString(), // 15 days ago
        dueDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), // 10 days ago
      },
    ]

    setTasks(mockTasks)
  }, [])

  const getTaskById = useCallback(
    (id: string) => {
      return tasks.find((task) => task.id === id)
    },
    [tasks],
  )

  const addTask = useCallback(
    (taskData: Partial<Task>) => {
      if (!user) return null

      const newTask: Task = {
        id: Date.now().toString(),
        title: taskData.title || "New Task",
        description: taskData.description || "",
        type: taskData.type || "Task",
        priority: taskData.priority || "Medium",
        status: taskData.status || "To Do",
        projectId: taskData.projectId || "",
        projectName: "Unknown Project", // This would be fetched from the project in a real app
        assignee: {
          id: user.email,
          name: user.name,
          role: user.role,
          avatar: user.avatar,
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        dueDate: taskData.dueDate || new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days from now
      }

      setTasks((prev) => [...prev, newTask])
      return newTask
    },
    [user],
  )

  const updateTask = useCallback((id: string, taskData: Partial<Task>) => {
    setTasks((prev) =>
      prev.map((task) => {
        if (task.id === id) {
          return {
            ...task,
            ...taskData,
            updatedAt: new Date().toISOString(),
          }
        }
        return task
      }),
    )
  }, [])

  const deleteTask = useCallback((id: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== id))
  }, [])

  return {
    tasks,
    getTaskById,
    addTask,
    updateTask,
    deleteTask,
  }
}
